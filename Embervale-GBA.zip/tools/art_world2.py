"""Extra outdoor art: richer grass, cast shadows, house details, village props and forest flora.
Everything here is registered into the outdoor Tileset by extend_outdoor(); art_maps.py places it."""
import math
import random
from common import Canvas
import art_world as AW
from art_world import grass_base, fill, SOLID, CUT, H

# palette banks 10 and 11 (outdoor.palette() already has room for them)
BANK_PROPS = 10     # warm props: wood, stone, hay, lantern, water
BANK_FLORA = 11     # forest flora: ferns, bark, mushrooms, glow flowers


def outline_around(c, solid, ink, idxs=(1, 2, 3)):
    """ink-coloured outline on background pixels (grass idx) that touch any pixel in `solid`."""
    src = c.a.copy()
    for y in range(c.h):
        for x in range(c.w):
            if src[y, x] in idxs:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < c.w and 0 <= yy < c.h and src[yy, xx] in solid:
                        c.set(x, y, ink)
                        break


# ---------------------------------------------------------------- grass
def grass_patch(kind, seed):
    c = grass_base(seed, 2 if kind == 'tall' else 4)
    r = random.Random(seed * 7 + 3)

    def rp():
        return r.randint(0, 15), r.randint(0, 15)
    if kind == 'light':
        for _ in range(18):
            c.set(*rp(), 2)
        for _ in range(5):
            c.set(*rp(), 14)
    elif kind == 'dark':
        for _ in range(16):
            c.set(*rp(), 3)
        for _ in range(4):
            x, y = rp()
            c.set(x, y, 13)
    elif kind == 'tall':
        for (x, y) in ((3, 7), (8, 4), (12, 9), (6, 11)):
            c.rect(x, y, x, y + 4, 4)
            c.set(x - 1, y + 1, 4)
            c.set(x + 1, y, 13)
            c.set(x + 1, y + 2, 13)
            c.set(x, y - 1, 14)
    elif kind == 'clover':
        for (x, y) in ((3, 4), (10, 8), (5, 12)):
            for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1)):
                c.set(x + dx, y + dy, 13)
            c.set(x, y, 14)
            c.set(x + 2, y + 1, 4)
            c.set(x - 1, y + 1, 4)
    elif kind == 'dandelion':
        for (x, y) in ((3, 4), (11, 7), (7, 12)):
            c.set(x, y, 6)
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                c.set(x + dx, y + dy, 5)
            c.set(x, y + 2, 4)
            c.set(x, y + 3, 4)
    elif kind == 'pebbles':
        for (x, y) in ((3, 5), (10, 9), (6, 12), (12, 3)):
            c.rect(x, y, x + 1, y, 12)
            c.set(x, y + 1, 3)
            c.set(x + 1, y + 1, 3)
            c.set(x, y - 1 if y > 0 else y, 10)
    return c


def shadow(kind):
    """cast shadow on grass (light comes from the top-left): dithered dark grass."""
    c = grass_base(5, 3)
    for y in range(16):
        for x in range(16):
            if kind == 'eave':
                t = y
            elif kind == 'side':
                t = x
            else:                      # corner: shadow in the top-left quadrant of the tile
                t = max(x, y) - 1
            if t < 2 or (t == 2 and (x + y) % 2 == 0) or (t == 3 and (x % 2 == 0 and y % 2 == 0)) or (t == 4 and x % 4 == 0 and y % 4 == 0):
                c.set(x, y, 3)
    return c


# ---------------------------------------------------------------- house details
def window_box():
    c = AW.wall('window')
    c.rect(3, 12, 12, 14, 4)
    c.rect(3, 12, 12, 12, 5)
    c.rect(3, 14, 12, 14, 6)
    for x, col in ((4, 14), (6, 13), (8, 14), (10, 13), (11, 14)):
        c.set(x, 11, col)
        c.set(x, 10, col if x % 2 == 0 else 13)
    return c


def step_stone():
    c = grass_base(9, 2)
    c.rect(3, 1, 12, 7, 5)          # bank 7: 4 light stone, 5 mid, 6 dark
    c.rect(3, 1, 12, 1, 4)
    c.rect(3, 7, 12, 7, 6)
    c.rect(12, 1, 12, 7, 6)
    c.set(6, 4, 6)
    c.set(9, 3, 6)
    return c


def chimney_roof(side_bank_red=True):
    """roof tile (middle, top row) with a brick chimney growing out of it."""
    c = AW.roof('m', 0)
    c.rect(9, 1, 13, 9, 5)          # roof banks 4/5: 5 brown, 12 tan, 6 dark brown, 13 darkest
    c.rect(9, 1, 9, 9, 12)
    c.rect(13, 1, 13, 9, 6)
    for y in (3, 6):
        c.rect(9, y, 13, y, 6)
    c.rect(8, 0, 14, 0, 13)
    return c


def chimney_top():
    """overlay above the roof row: the upper chimney and a puff of smoke (transparent background)."""
    c = Canvas(16, 16)
    c.rect(9, 7, 13, 15, 5)
    c.rect(9, 7, 9, 15, 12)
    c.rect(13, 7, 13, 15, 6)
    for y in (9, 12):
        c.rect(9, y, 13, y, 6)
    c.rect(8, 6, 14, 6, 13)
    c.rect(8, 7, 8, 7, 13)
    c.rect(14, 7, 14, 7, 13)
    for (x, y, col) in ((10, 3, 7), (11, 2, 7), (12, 3, 8), (11, 0, 7), (13, 1, 7), (10, 1, 8), (9, 4, 7)):
        c.set(x, y, col)
    return c


# ---------------------------------------------------------------- plaza / water variants
def plaza_variant(kind):
    c = AW.path_tile(True, True, True, True, True, True, True, True, style='stone')
    r = random.Random(77 if kind == 'crack' else 78)
    if kind == 'crack':
        x, y = 3, 2
        for _ in range(10):
            c.set(x, y, 12)
            x += r.choice((0, 1, 1))
            y += r.choice((1, 1, 0))
    elif kind == 'moss':
        for _ in range(9):
            c.set(r.randint(1, 14), r.randint(1, 14), r.choice((2, 3)))
        for (x, y) in ((4, 4), (10, 11)):
            c.rect(x, y, x + 1, y + 1, 3)
    elif kind == 'inlay':
        c = c.remap({10: 11, 11: 12})
    return c


def lily_water():
    c = AW.water_tile(True, True, True, True, True, True, True, True)
    for (cx, cy, rr) in ((4.5, 5.0, 3.0), (11.0, 10.5, 3.4)):
        c.ellipse(cx, cy, rr, rr * 0.75, 12)
        c.ellipse(cx - 0.6, cy - 0.5, rr * 0.65, rr * 0.45, 11)
        c.set(int(cx + rr * 0.6), int(cy), 4)         # the notch
    c.set(10, 9, 13)
    c.set(11, 9, 13)
    c.set(10, 10, 13)
    return c


def reeds():
    c = grass_base(13, 2)
    for (x, h) in ((3, 9), (6, 11), (9, 8), (12, 10)):
        c.rect(x, 14 - h, x, 14, 12)
        c.set(x + 1, 14 - h // 2, 14)
        c.rect(x, 14 - h - 1, x, 14 - h + 1, 9)
        c.set(x, 14 - h - 2, 8)
    return c


# ---------------------------------------------------------------- village props (bank 10)
def barrel():
    c = grass_base(111, 2)
    c.ellipse(7.5, 8.5, 5.8, 6.8, 7)
    c.ellipse(7.5, 8.5, 5.0, 6.0, 5)
    c.ellipse(6.5, 8.0, 3.0, 5.2, 4)
    for y in range(16):
        for x in range(16):
            if c.get(x, y) == 5 and x > 9:
                c.set(x, y, 6)
    c.rect(3, 4, 12, 4, 9)
    c.rect(3, 12, 12, 12, 9)
    c.rect(3, 3, 12, 3, 8) if False else None
    c.rect(5, 2, 10, 3, 6)
    c.rect(5, 2, 10, 2, 5)
    c.rect(7, 8, 8, 9, 7)
    return c


def crate():
    c = grass_base(112, 2)
    c.rect(2, 3, 13, 13, 5)
    c.rect(2, 3, 13, 3, 4)
    c.rect(2, 13, 13, 13, 7)
    c.rect(2, 3, 2, 13, 4)
    c.rect(13, 3, 13, 13, 6)
    c.line(3, 4, 12, 12, 6)
    c.line(12, 4, 3, 12, 6)
    c.line(3, 5, 11, 12, 7) if False else None
    c.rect(2, 3, 13, 3, 7) if False else None
    outline_around(c, (4, 5, 6, 7), 7)
    return c


def hay():
    c = grass_base(113, 2)
    c.ellipse(7.5, 9.0, 7.0, 5.4, 12)
    c.ellipse(7.5, 8.4, 6.4, 4.6, 11)
    for (x0, y0, x1, y1) in ((2, 7, 6, 7), (8, 6, 12, 6), (4, 10, 9, 10), (10, 9, 13, 9), (3, 8, 4, 8)):
        c.line(x0, y0, x1, y1, 10)
    c.rect(7, 4, 8, 12, 6)
    outline_around(c, (11, 12), 7)
    return c


def well_base():
    c = grass_base(114, 2)
    c.ellipse(7.5, 10.5, 7.0, 4.6, 9)
    c.ellipse(7.5, 9.8, 7.0, 4.4, 8)
    c.ellipse(7.5, 10.0, 4.8, 2.6, 7)
    c.ellipse(7.5, 10.2, 4.2, 2.1, 15)
    c.rect(2, 2, 3, 10, 5)
    c.rect(12, 2, 13, 10, 5)
    c.rect(2, 2, 2, 10, 4)
    c.rect(13, 2, 13, 10, 6)
    c.set(7, 10, 8)
    c.set(8, 11, 8)
    return c


def well_roof():
    c = Canvas(16, 16)
    for y in range(3, 14):
        half = 2 + (y - 3) * 0.7
        x0, x1 = int(7.5 - half), int(7.5 + half)
        c.rect(x0, y, x1, y, 5 if (y - 3) % 3 else 4)
        c.set(x0, y, 7)
        c.set(x1, y, 7)
    c.rect(0, 13, 15, 13, 7)
    c.rect(5, 2, 10, 3, 4)
    c.rect(7, 1, 8, 2, 6)
    c.rect(2, 14, 3, 15, 5)
    c.rect(12, 14, 13, 15, 5)
    return c


def lamp_base():
    c = grass_base(115, 2)
    c.rect(6, 5, 9, 15, 9)
    c.rect(6, 5, 6, 15, 8)
    c.rect(4, 13, 11, 15, 9)
    c.rect(4, 13, 11, 13, 8)
    outline_around(c, (8, 9), 7)
    return c


def lamp_top():
    c = Canvas(16, 16)
    c.rect(6, 8, 9, 15, 9)
    c.rect(6, 8, 6, 15, 8)
    c.rect(4, 1, 11, 7, 9)
    c.rect(5, 2, 10, 6, 13)
    c.rect(6, 3, 9, 5, 14)
    c.rect(3, 0, 12, 1, 8)
    c.rect(5, 7, 10, 7, 8)
    for (x, y) in ((2, 4), (13, 4), (7, 0)):
        c.set(x, y, 13)
    return c


def bench():
    c = grass_base(116, 2)
    c.rect(1, 3, 14, 6, 5)
    c.rect(1, 3, 14, 3, 4)
    c.rect(1, 6, 14, 6, 6)
    c.rect(1, 8, 14, 10, 5)
    c.rect(1, 8, 14, 8, 4)
    c.rect(1, 10, 14, 10, 6)
    c.rect(2, 11, 3, 14, 7)
    c.rect(12, 11, 13, 14, 7)
    c.rect(2, 11, 2, 14, 6)
    outline_around(c, (4, 5, 6, 7), 7)
    return c


def planter():
    c = grass_base(117, 2)
    c.rect(2, 8, 13, 14, 5)
    c.rect(2, 8, 13, 8, 4)
    c.rect(2, 14, 13, 14, 7)
    c.rect(13, 8, 13, 14, 6)
    for x in range(3, 13, 2):
        c.rect(x, 5, x, 7, 2)
        c.set(x + 1, 6, 3)
    for (x, y, col) in ((3, 4, 14), (5, 3, 13), (7, 4, 14), (9, 3, 13), (11, 4, 14)):
        c.set(x, y, col)
        c.set(x, y + 1, col)
    outline_around(c, (4, 5, 6, 7), 7)
    return c


def garden(kind):
    c = Canvas(16, 16)
    fill(c, 6)
    for y in (3, 7, 11, 15):
        c.rect(0, y, 15, y, 7)
    for y in (2, 6, 10, 14):
        for x in range(0, 16, 4):
            xx = x + (y // 4) % 2 * 2
            if kind == 'a':                         # round leafy crops
                c.ellipse(xx + 1.5, y - 0.5, 1.8, 1.6, 2)
                c.set(xx + 1, y - 1, 3)
            else:                                    # carrot tops
                c.rect(xx, y - 2, xx, y, 3)
                c.set(xx - 1, y - 2, 2)
                c.set(xx + 1, y - 2, 2)
                c.set(xx, y + 1, 14)
    return c


def log_pile():
    c = grass_base(118, 2)
    for (cx, cy) in ((4.5, 10.5), (11.0, 10.5), (7.8, 5.5)):
        c.ellipse(cx, cy, 3.6, 3.6, 7)
        c.ellipse(cx, cy, 3.0, 3.0, 4)
        c.ellipse(cx, cy, 1.6, 1.6, 5)
        c.set(int(cx), int(cy), 6)
    outline_around(c, (4, 5, 7), 7)
    return c


# ---------------------------------------------------------------- forest flora (bank 11)
def fern(seed):
    c = grass_base(seed, 2)
    for (ang, ln) in ((-62, 6), (-32, 8), (0, 9), (32, 8), (62, 6)):
        a = math.radians(ang)
        x1, y1 = 7.5 + math.sin(a) * ln, 13 - math.cos(a) * ln
        c.line(7, 13, int(round(x1)), int(round(y1)), 5)
        c.set(int(round(x1)), int(round(y1)), 6)
        mx, my = (7.5 + x1) / 2, (13 + y1) / 2
        c.set(int(round(mx)) - 1, int(round(my)), 6)
        c.set(int(round(mx)) + 1, int(round(my)), 4)
    c.rect(6, 12, 8, 14, 4)
    c.set(7, 13, 5)
    return c


def log_fallen(side):
    c = grass_base(119, 2)
    c.rect(side == 'l' and 4 or 0, 6, side == 'l' and 15 or 11, 12, 7)
    x0 = 4 if side == 'l' else 0
    x1 = 15 if side == 'l' else 11
    c.rect(x0, 6, x1, 7, 8)
    c.rect(x0, 11, x1, 12, 9)
    for x in range(x0 + 2, x1, 4):
        c.set(x, 9, 9)
        c.set(x + 1, 8, 9)
    # moss on top
    for x in range(x0 + 1, x1, 3):
        c.set(x, 6, 14)
        c.set(x + 1, 6, 15)
    if side == 'l':
        c.ellipse(5.0, 9.0, 2.6, 3.4, 8)
        c.ellipse(5.0, 9.0, 1.6, 2.2, 7)
        c.set(5, 9, 8)
    else:
        c.ellipse(11.0, 9.0, 2.6, 3.4, 8)
        c.ellipse(11.0, 9.0, 1.6, 2.2, 7)
        c.set(11, 9, 8)
    outline_around(c, (7, 8, 9), 9)
    return c


def mushroom_big():
    c = grass_base(120, 2)
    for (x, y, rr) in ((4, 8, 3.2), (10, 6, 2.6), (8, 11, 2.2)):
        c.rect(int(x) - 1, int(y) + 1, int(x), int(y) + 4, 11)
        c.ellipse(x, y, rr, rr * 0.7, 10)
        c.set(int(x) - 1, int(y) - 1, 11)
        c.set(int(x) + 1, int(y), 11)
        c.set(int(x), int(y) + 1, 9)
    return c


def dead_tree():
    base = grass_base(121, 2)
    base.rect(6, 0, 9, 13, 7)
    base.rect(6, 0, 7, 13, 8)
    base.rect(9, 0, 9, 13, 9)
    base.rect(4, 12, 11, 14, 7)
    base.set(4, 14, 9)
    base.set(11, 14, 9)
    base.rect(5, 11, 5, 13, 8)
    base.set(8, 6, 9)
    base.set(7, 9, 9)
    top = Canvas(16, 16)
    top.rect(6, 8, 9, 15, 7)
    top.rect(6, 8, 7, 15, 8)
    top.rect(9, 8, 9, 15, 9)
    top.line(6, 9, 2, 3, 7)
    top.line(9, 8, 13, 2, 7)
    top.line(7, 8, 8, 0, 7)
    top.line(4, 5, 1, 6, 9)
    top.line(12, 4, 15, 5, 9)
    top.line(2, 3, 2, 1, 9)
    return base, top


def floor_leaves(seed, dense):
    c = grass_base(seed, 3)
    r = random.Random(seed)
    for _ in range(dense):
        c.set(r.randint(0, 15), r.randint(0, 15), r.choice((8, 9, 8)))
    for _ in range(4):
        c.set(r.randint(0, 15), r.randint(0, 15), 14)
    return c


def glow_flowers():
    c = grass_base(122, 2)
    for (x, y) in ((4, 5), (10, 4), (7, 10), (12, 12)):
        c.set(x, y, 12)
        c.set(x - 1, y, 13)
        c.set(x + 1, y, 13)
        c.set(x, y - 1, 13)
        c.set(x, y + 1, 12)
        c.set(x, y, 11)
        c.set(x, y + 2, 5)
    return c


def moss_rock():
    c = AW.rock()
    for (x, y) in ((5, 5), (6, 5), (7, 5), (6, 6), (9, 6), (10, 6), (4, 7), (5, 7)):
        if c.get(x, y) in (3, 4, 5, 6):
            c.set(x, y, 3 if (x + y) % 2 else 2)
    return c


# ---------------------------------------------------------------- registration
def extend_outdoor(ts):
    ts.add('grass_light', grass_patch('light', 11), 0)
    ts.add('grass_dark', grass_patch('dark', 12), 0)
    ts.add('grass_tall', grass_patch('tall', 13), 0)
    ts.add('grass_clover', grass_patch('clover', 14), 0)
    ts.add('grass_dand', grass_patch('dandelion', 15), 0)
    ts.add('grass_peb', grass_patch('pebbles', 16), 0)
    ts.add('shadow_eave', shadow('eave'), 0)
    ts.add('shadow_side', shadow('side'), 0)
    ts.add('window_box', window_box(), 3, SOLID)
    ts.add('step_stone', step_stone(), 7, 0)
    ts.add('chimney_roof_r', chimney_roof(), 4, SOLID)
    ts.add('chimney_roof_b', chimney_roof(), 5, SOLID)
    ts.add('chimney_top_r', chimney_top(), 4, 0)
    ts.add('chimney_top_b', chimney_top(), 5, 0)
    ts.add('plaza_crack', plaza_variant('crack'), 1, 0)
    ts.add('plaza_moss', plaza_variant('moss'), 1, 0)
    ts.add('plaza_inlay', plaza_variant('inlay'), 1, 0)
    ts.add('water_lily', lily_water(), 2, 3)
    ts.add('reeds', reeds(), 2, 0)
    ts.add('barrel', barrel(), BANK_PROPS, SOLID)
    ts.add('crate', crate(), BANK_PROPS, SOLID)
    ts.add('hay', hay(), BANK_PROPS, SOLID)
    ts.add('well_base', well_base(), BANK_PROPS, SOLID)
    ts.add('well_roof', well_roof(), BANK_PROPS, 0)
    ts.add('lamp_base', lamp_base(), BANK_PROPS, SOLID)
    ts.add('lamp_top', lamp_top(), BANK_PROPS, 0)
    ts.add('bench', bench(), BANK_PROPS, SOLID)
    ts.add('planter', planter(), BANK_PROPS, SOLID)
    ts.add('garden_a', garden('a'), BANK_PROPS, SOLID)
    ts.add('garden_b', garden('b'), BANK_PROPS, SOLID)
    ts.add('log_pile', log_pile(), BANK_PROPS, SOLID)
    ts.add('fern_a', fern(131), BANK_FLORA, 0)
    ts.add('fern_b', fern(132), BANK_FLORA, 0)
    ts.add('log_l', log_fallen('l'), BANK_FLORA, SOLID)
    ts.add('log_r', log_fallen('r'), BANK_FLORA, SOLID)
    ts.add('mushroom_big', mushroom_big(), BANK_FLORA, 0)
    base, top = dead_tree()
    ts.add('dead_trunk', base, BANK_FLORA, SOLID)
    ts.add('dead_top', top, BANK_FLORA, 0)
    ts.add('floor_leaves_a', floor_leaves(141, 9), BANK_FLORA, 0)
    ts.add('floor_leaves_b', floor_leaves(142, 16), BANK_FLORA, 0)
    ts.add('glow_flowers', glow_flowers(), BANK_FLORA, 0)
    ts.add('moss_rock', moss_rock(), 7, SOLID)
