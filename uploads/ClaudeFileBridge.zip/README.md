# Claude FileBridge

Android app + Supabase backend that lets Claude work with files on your phone through a custom MCP connector.
Files stay on the phone. Supabase only relays small commands and small results.

```
Claude -> MCP (Edge Function filebridge-mcp) -> command queue -> signed Realtime wake
       -> phone (FileBridge app) -> local file operations (Storage Access Framework) -> small result -> Claude
```

## Build the app
- Project root = ZIP root. JDK 17, Android SDK 35: `./gradlew assembleDebug` (or `assembleRelease`, debug-signed and minified).
  `gradlew` is included; it uses `gradle/wrapper/gradle-wrapper.jar` and downloads that jar itself if it is missing. The wrapper downloads Gradle 8.9 (required by AGP 8.7).
- One universal APK. No ABI splits, no abiFilters. minSdk 26, targetSdk 34.
- This project was written without a Kotlin toolchain available, so it has not been compiled yet. If CI reports a compile error, send the log and it gets fixed.

## Backend (Supabase project uvxrpymncajhqtqpwdsb)
- Schema, RLS and helper functions: `supabase/migrations/20261005_filebridge_schema_v1.sql` (already applied).
- Edge Function: `supabase/functions/filebridge-mcp/index.ts`.
  Deploy with JWT verification OFF (the function authenticates every call itself).
  Dashboard route: Edge Functions > Deploy a new function > Via Editor > name `filebridge-mcp` > paste the file > Deploy,
  then Function details > turn off "Enforce JWT verification".
- Health check: `GET https://uvxrpymncajhqtqpwdsb.supabase.co/functions/v1/filebridge-mcp/health`

## First run on the phone
1. Setup: backend URL is pre-filled. Enter the one-time pairing code and tap Pair.
2. Select Folder for Claude Workspace (for example Download/Claude). ZIP / APK / Build folders are optional;
   without them `ZIP/`, `APK/` and `BuildWorkspace/` are sub-folders of the workspace.
3. Start FileBridge. It runs as a foreground service so you can keep using the phone. Stop it from the notification or the home screen.
4. In Claude: Settings > Connectors > Add custom connector > paste the connector URL (it contains a private key, treat it like a password).
5. Battery: set FileBridge to Unrestricted (button in Settings). On Infinix XOS also allow Auto-start.
6. For builds: Settings > Build provider (GitHub): owner, repo, branch, workflow file, ZIP path in the repo, token.

## Safety model
- Claude only gets 19 narrow tools. There is no shell / exec / terminal tool.
- The phone enforces everything: workspace-only paths (`..` rejected), permission toggles, confirmations, no silent overwrite.
  Move / Delete / Upload are OFF by default. Deleting always asks on the phone.
- Commands are signed (HMAC) per device, carry an ID, timestamp, expiry and nonce, and are accepted once.
  Destructive commands expire in 45 s and are discarded if the phone was away. Replays are rejected.
- Per-device bearer token (hash stored server-side), secrets encrypted with the Android Keystore. RLS denies all direct table access.
- Realtime only carries tiny signed wake pings; commands and results travel over authenticated HTTPS and results are purged once delivered.
- Emergency Stop cancels ZIPs, uploads and pending operations and pauses Claude. It never deletes files.
- ZIPs are streamed to `NAME.zip.tmp` and renamed on success; failures remove the temp file. Extraction blocks path traversal and rolls back on error.
- Low resource use: no background scanning, indexing, polling or screenshots; one heartbeat about every 25 s while idle; one heavy operation at a time.
