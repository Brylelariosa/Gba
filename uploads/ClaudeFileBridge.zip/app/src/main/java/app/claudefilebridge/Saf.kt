package app.claudefilebridge

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.webkit.MimeTypeMap
import java.io.InputStream
import java.io.OutputStream

class Node(
    val name: String,
    val docId: String,
    val uri: Uri,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val mime: String
)

fun mimeFor(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    if (ext.isEmpty()) return "application/octet-stream"
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
}

fun treeLabel(uri: String?): String {
    if (uri == null) return "Not set"
    return try {
        val id = DocumentsContract.getTreeDocumentId(Uri.parse(uri))
        val p = id.substringAfter(':', id)
        if (p.isEmpty()) "(storage root)" else p
    } catch (e: Exception) {
        uri
    }
}

/** One persisted SAF tree (a folder the user picked). All access goes through DocumentsContract queries. */
class Tree(private val ctx: Context, val treeUri: Uri) {
    private val cr: ContentResolver = ctx.contentResolver
    val rootId: String = DocumentsContract.getTreeDocumentId(treeUri)
    private val cols = arrayOf(
        Document.COLUMN_DOCUMENT_ID,
        Document.COLUMN_DISPLAY_NAME,
        Document.COLUMN_MIME_TYPE,
        Document.COLUMN_SIZE,
        Document.COLUMN_LAST_MODIFIED
    )

    private fun docUri(id: String): Uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)

    private fun node(c: Cursor): Node {
        val id = c.getString(0)
        val mime = c.getString(2) ?: ""
        return Node(
            c.getString(1) ?: "",
            id,
            docUri(id),
            mime == Document.MIME_TYPE_DIR,
            if (c.isNull(3)) -1L else c.getLong(3),
            if (c.isNull(4)) 0L else c.getLong(4),
            mime
        )
    }

    fun stat(id: String): Node? = try {
        cr.query(docUri(id), cols, null, null, null)?.use { if (it.moveToFirst()) node(it) else null }
    } catch (e: Exception) {
        null
    }

    fun root(): Node? = stat(rootId)

    fun children(p: Node): List<Node> {
        val out = ArrayList<Node>()
        try {
            val uri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, p.docId)
            cr.query(uri, cols, null, null, null)?.use { while (it.moveToNext()) out.add(node(it)) }
        } catch (e: Exception) {
            throw OpError("storage_error", "Cannot read folder '${p.name}': ${e.message}")
        }
        return out
    }

    fun child(p: Node, name: String): Node? = children(p).firstOrNull { it.name == name }

    fun find(segs: List<String>): Node? {
        var cur = root() ?: return null
        for (s in segs) cur = child(cur, s) ?: return null
        return cur
    }

    fun mkdir(p: Node, name: String): Node {
        val u = try {
            DocumentsContract.createDocument(cr, p.uri, Document.MIME_TYPE_DIR, name)
        } catch (e: Exception) {
            null
        }
        val id = u?.let { DocumentsContract.getDocumentId(it) } ?: throw OpError("storage_error", "Cannot create folder '$name'")
        return stat(id) ?: throw OpError("storage_error", "Created folder not found: $name")
    }

    fun ensureDir(segs: List<String>): Node {
        var cur = root() ?: throw OpError("storage_error", "That folder is not accessible any more. Pick it again in Settings > Storage.")
        for (s in segs) {
            val c = child(cur, s)
            cur = when {
                c == null -> mkdir(cur, s)
                c.isDir -> c
                else -> throw OpError("not_a_directory", "'$s' exists and is a file, not a folder")
            }
        }
        return cur
    }

    fun createFile(p: Node, name: String): Node {
        val u = try {
            DocumentsContract.createDocument(cr, p.uri, mimeFor(name), name)
        } catch (e: Exception) {
            null
        }
        val id = u?.let { DocumentsContract.getDocumentId(it) } ?: throw OpError("storage_error", "Cannot create '$name'")
        return stat(id) ?: throw OpError("storage_error", "Created file not found: $name")
    }

    fun delete(n: Node): Boolean = try {
        DocumentsContract.deleteDocument(cr, n.uri)
    } catch (e: Exception) {
        false
    }

    fun rename(n: Node, newName: String): Node? = try {
        DocumentsContract.renameDocument(cr, n.uri, newName)?.let { stat(DocumentsContract.getDocumentId(it)) }
    } catch (e: Exception) {
        null
    }

    fun move(n: Node, from: Node, to: Node): Node? = try {
        DocumentsContract.moveDocument(cr, n.uri, from.uri, to.uri)?.let { stat(DocumentsContract.getDocumentId(it)) }
    } catch (e: Exception) {
        null
    }

    fun openIn(n: Node): InputStream = cr.openInputStream(n.uri) ?: throw OpError("storage_error", "Cannot open '${n.name}'")

    fun openOut(n: Node): OutputStream = cr.openOutputStream(n.uri, "wt") ?: throw OpError("storage_error", "Cannot write '${n.name}'")

    /** Free bytes on the volume holding this tree (best effort). */
    fun freeBytes(): Long {
        val vol = rootId.substringBefore(':', "primary")
        var path: String? = null
        if (vol != "primary" && Build.VERSION.SDK_INT >= 30) {
            try {
                val sm = ctx.getSystemService(StorageManager::class.java)
                path = sm.storageVolumes.firstOrNull { it.uuid.equals(vol, true) }?.directory?.path
            } catch (e: Exception) {
            }
        }
        return try {
            StatFs(path ?: Environment.getExternalStorageDirectory().path).availableBytes
        } catch (e: Exception) {
            Long.MAX_VALUE
        }
    }
}

object PathUtil {
    /** Splits a virtual path and rejects traversal. */
    fun split(p: String): List<String> {
        if (p.length > 1024) throw OpError("invalid_path", "Path too long")
        val segs = p.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
        for (s in segs) {
            if (s == ".." || s.contains('\u0000')) throw OpError("invalid_path", "Paths may not contain '..'")
        }
        if (segs.size > 64) throw OpError("invalid_path", "Path too deep")
        return segs
    }

    fun join(segs: List<String>): String = segs.joinToString("/")
}

/**
 * Small glob: * (no '/'), ** (anything), ? ; a pattern without '/' matches names at any depth;
 * a trailing '/' means "folders only".
 */
class Glob(pattern: String) {
    private val dirOnly = pattern.trim().endsWith("/")
    private val core = pattern.trim().trimEnd('/').removePrefix("./").trimStart('/')
    private val anyDepth = !core.contains('/')
    private val rx: Regex = build(core)

    private fun build(s: String): Regex {
        val sb = StringBuilder("^")
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '*' && i + 1 < s.length && s[i + 1] == '*') {
                if (i + 2 < s.length && s[i + 2] == '/') {
                    sb.append("(?:.*/)?")
                    i += 3
                } else {
                    sb.append(".*")
                    i += 2
                }
                continue
            }
            when {
                c == '*' -> sb.append("[^/]*")
                c == '?' -> sb.append("[^/]")
                "\\.[]{}()+-^$|".indexOf(c) >= 0 -> sb.append('\\').append(c)
                else -> sb.append(c)
            }
            i++
        }
        sb.append("$")
        return Regex(sb.toString())
    }

    fun matches(rel: String, isDir: Boolean): Boolean {
        if (core.isEmpty()) return false
        if (dirOnly && !isDir) return false
        val target = if (anyDepth) rel.substringAfterLast('/') else rel
        return rx.matches(target)
    }
}
