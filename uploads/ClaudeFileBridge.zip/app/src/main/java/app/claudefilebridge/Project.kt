package app.claudefilebridge

import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.zip.Deflater

/** Text-level edits applied to the STAGED copy only (never to the original project). */
object GradleTransforms {
    private fun matchBrace(t: String, open: Int): Int {
        var depth = 0
        var i = open
        var quote = '\u0000'
        while (i < t.length) {
            val c = t[i]
            if (quote != '\u0000') {
                if (c == '\\') {
                    i++
                } else if (c == quote) {
                    quote = '\u0000'
                }
            } else if (c == '"' || c == '\'') {
                quote = c
            } else if (c == '/' && i + 1 < t.length && t[i + 1] == '/') {
                while (i < t.length && t[i] != '\n') i++
            } else if (c == '/' && i + 1 < t.length && t[i + 1] == '*') {
                val e = t.indexOf("*/", i + 2)
                i = if (e < 0) t.length else e + 1
            } else if (c == '{') {
                depth++
            } else if (c == '}') {
                depth--
                if (depth == 0) return i
            }
            i++
        }
        return -1
    }

    /** Range from the block name to its closing brace, or null. */
    fun findBlock(t: String, name: String, from: Int = 0): IntRange? {
        val m = Regex("\\b" + Regex.escape(name) + "\\s*\\{").find(t, from) ?: return null
        val close = matchBrace(t, m.range.last)
        if (close < 0) return null
        return m.range.first..close
    }

    fun hasAbiSplits(t: String): Boolean {
        val sp = findBlock(t, "splits") ?: return false
        return findBlock(t.substring(sp.first, sp.last + 1), "abi") != null
    }

    /** Universal APK guarantee: drop `splits { abi { ... } }` from the staged build file. */
    fun removeAbiSplits(t: String): Pair<String, Boolean> {
        val sp = findBlock(t, "splits") ?: return Pair(t, false)
        val inner = t.substring(sp.first, sp.last + 1)
        val ab = findBlock(inner, "abi") ?: return Pair(t, false)
        val newInner = inner.substring(0, ab.first) + "// FileBridge: ABI splits removed (universal APK)\n" + inner.substring(ab.last + 1)
        return Pair(t.substring(0, sp.first) + newInner + t.substring(sp.last + 1), true)
    }

    /** Turns on R8 + resource shrinking in the release build type. */
    fun enableShrink(t: String, kts: Boolean): Pair<String, Boolean> {
        val bt = findBlock(t, "buildTypes") ?: return Pair(t, false)
        val sub = t.substring(bt.first, bt.last + 1)
        val rel = Regex("\\b(release|getByName\\(\"release\"\\)|named\\(\"release\"\\))\\s*\\{").find(sub) ?: return Pair(t, false)
        val open = rel.range.last
        val close = matchBrace(sub, open)
        if (close < 0) return Pair(t, false)
        var body = sub.substring(open + 1, close)
        val minOn = if (kts) "isMinifyEnabled = true" else "minifyEnabled true"
        val shrOn = if (kts) "isShrinkResources = true" else "shrinkResources true"
        val minRx = Regex("(isMinifyEnabled|minifyEnabled)\\s*=?\\s*(true|false)")
        val shrRx = Regex("(isShrinkResources|shrinkResources)\\s*=?\\s*(true|false)")
        val minTrue = Regex("(isMinifyEnabled|minifyEnabled)\\s*=?\\s*true")
        val shrTrue = Regex("(isShrinkResources|shrinkResources)\\s*=?\\s*true")
        var changed = false
        if (minRx.containsMatchIn(body)) {
            if (!minTrue.containsMatchIn(body)) changed = true
            body = minRx.replace(body, minOn)
        } else {
            changed = true
            body = "\n            $minOn" + body
        }
        if (shrRx.containsMatchIn(body)) {
            if (!shrTrue.containsMatchIn(body)) changed = true
            body = shrRx.replace(body, shrOn)
        } else {
            changed = true
            body = "\n            $shrOn" + body
        }
        val newSub = sub.substring(0, open + 1) + body + sub.substring(close)
        return Pair(t.substring(0, bt.first) + newSub + t.substring(bt.last + 1), changed)
    }
}

class Scan {
    val cats = linkedMapOf("build_artifacts" to 0L, "debug_resources" to 0L, "caches" to 0L, "vcs" to 0L, "user_excluded" to 0L)
    var kept = 0L
    var keptFiles = 0
    var abiSplits = false
    var native = false
    var minify = false

    fun add(cat: String, n: Long) {
        cats[cat] = (cats[cat] ?: 0L) + n
    }

    fun removable(): Long = cats.values.sum()
    fun cat(k: String): Long = cats[k] ?: 0L
}

object ProjectPreparer {
    private const val MARKER = ".filebridge-staging"
    private val BUILD_FILES = setOf("build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "pom.xml")

    /** Category of things that are safe to leave out of a CI upload; null = unknown, so it is preserved. */
    private fun classify(rel: String, name: String, isDir: Boolean, parentHasBuild: Boolean): String? {
        if (isDir) {
            return when {
                name == ".gradle" || name == ".kotlin" || name == ".idea" -> "caches"
                name == ".cxx" || name == ".externalNativeBuild" -> "build_artifacts"
                name == "build" && parentHasBuild -> "build_artifacts"
                name == ".git" -> "vcs"
                rel == "src/debug" || rel.endsWith("/src/debug") -> "debug_resources"
                rel == "src/androidTest" || rel.endsWith("/src/androidTest") -> "debug_resources"
                rel == "src/test" || rel.endsWith("/src/test") -> "debug_resources"
                else -> null
            }
        }
        val junk = name == "local.properties" || name == ".DS_Store" || name == "Thumbs.db" || name.endsWith(".iml") || name.endsWith(".hprof")
        return if (junk) "caches" else null
    }

    private fun isGradleFile(n: Node): Boolean =
        !n.isDir && (n.name == "build.gradle" || n.name == "build.gradle.kts") && n.size in 1L..600_000L

    private fun readText(t: Tree, n: Node): String =
        try {
            t.openIn(n).use { it.readBytes().toString(Charsets.UTF_8) }
        } catch (e: Exception) {
            ""
        }

    private suspend fun scan(t: Tree, root: Node, extra: List<Glob>, optimize: Boolean): Scan {
        val s = Scan()
        suspend fun go(dir: Node, rel: String) {
            currentCoroutineContext().ensureActive()
            val kids = t.children(dir)
            val hasBuild = kids.any { !it.isDir && it.name in BUILD_FILES }
            for (c in kids) {
                val r = if (rel.isEmpty()) c.name else rel + "/" + c.name
                val auto: String? = if (optimize) classify(r, c.name, c.isDir, hasBuild) else null
                val label: String? = auto ?: (if (extra.any { it.matches(r, c.isDir) }) "user_excluded" else null)
                if (label != null) {
                    s.add(label, if (c.isDir) FileOps.sizeOf(t, c) else maxOf(c.size, 0L))
                    continue
                }
                if (c.isDir) {
                    if ((c.name == "cpp" || c.name == "jni") && r.contains("src/")) s.native = true
                    go(c, r)
                } else {
                    s.kept += maxOf(c.size, 0L)
                    s.keptFiles++
                    if (isGradleFile(c)) {
                        val txt = readText(t, c)
                        if (GradleTransforms.hasAbiSplits(txt)) s.abiSplits = true
                        if (txt.contains("externalNativeBuild") || txt.contains("ndkBuild") || txt.contains("cmake")) s.native = true
                        if (Regex("(isMinifyEnabled|minifyEnabled)\\s*=?\\s*true").containsMatchIn(txt)) s.minify = true
                    }
                }
            }
        }
        go(root, "")
        return s
    }

    private fun report(s: Scan, optimizeGradle: Boolean, optimize: Boolean): JSONObject {
        val total = s.kept + s.removable()
        val r8 = when {
            s.minify -> "already enabled in the project"
            s.native -> "skipped: native (NDK/JNI) code detected, shrinking could break it"
            optimizeGradle -> "will be enabled in the staged copy"
            else -> "not applied (pass optimize_gradle=true to enable R8 + resource shrinking in the staged copy)"
        }
        val abi = if (s.abiSplits) "DETECTED (removed in the staged copy)" else "DISABLED"
        val text = buildString {
            append("APK Optimization\n\n")
            append("Project size:\n").append(fmtBytes(total)).append("\n\n")
            append("Potential removable build artifacts:\n").append(fmtBytes(s.cat("build_artifacts"))).append("\n\n")
            append("Debug resources:\n").append(fmtBytes(s.cat("debug_resources"))).append("\n\n")
            append("Caches:\n").append(fmtBytes(s.cat("caches"))).append("\n\n")
            if (s.cat("vcs") > 0) append("Version-control data:\n").append(fmtBytes(s.cat("vcs"))).append("\n\n")
            if (s.cat("user_excluded") > 0) append("Excluded by you:\n").append(fmtBytes(s.cat("user_excluded"))).append("\n\n")
            append("ABI splits:\n").append(abi).append("\n\n")
            append("Universal APK:\nENABLED\n\n")
            append("R8 / resource shrinking: ").append(r8).append("\n")
            append("Unknown files are preserved (").append(fmtBytes(s.kept)).append(" kept).")
        }
        return jsonOf(
            "optimization_report" to text,
            "project_size" to total,
            "removable_bytes" to s.removable(),
            "kept_bytes" to s.kept,
            "optimize" to optimize,
            "removable" to jsonOf(
                "build_artifacts" to s.cat("build_artifacts"),
                "debug_resources" to s.cat("debug_resources"),
                "caches" to s.cat("caches"),
                "vcs" to s.cat("vcs"),
                "user_excluded" to s.cat("user_excluded")
            ),
            "abi_splits" to (if (s.abiSplits) "DETECTED (removed in staging)" else "DISABLED"),
            "universal_apk" to "ENABLED",
            "r8" to r8
        )
    }

    /** Stage a filtered copy in BuildWorkspace/<project>/, apply safe tweaks there, zip it. The original is never modified. */
    suspend fun prepare(
        project: String, output: String, optimize: Boolean, optimizeGradle: Boolean, dryRun: Boolean,
        keepStaging: Boolean, extra: List<String>, overwrite: Boolean, ctx: OpCtx
    ): JSONObject {
        val p = Workspace.loc(project)
        if (p.segs.isEmpty()) throw OpError("invalid_path", "Pick a project folder inside the workspace")
        val pn = FileOps.requireNode(p)
        if (!pn.isDir) throw OpError("not_a_directory", "The project must be a folder")
        val globs = extra.filter { it.isNotBlank() }.map { Glob(it) }

        ctx.progress(null, "Scanning project...")
        val sc = scan(p.tree, pn, globs, optimize)
        val rep = report(sc, optimizeGradle, optimize)
        if (dryRun) {
            rep.put("dry_run", true)
            return rep
        }

        val o = Workspace.loc(output)
        if (o.segs.isEmpty()) throw OpError("invalid_path", "Give an output path like ZIP/Name-build.zip")
        val name = p.segs.last()
        val bw = Workspace.loc("BuildWorkspace/$name")
        Space.guard(bw.tree, sc.kept * 2, ctx, "Preparing $name")

        val stageParent = bw.tree.ensureDir(bw.segs.dropLast(1))
        var stageName = bw.segs.last()
        val old = bw.tree.child(stageParent, stageName)
        if (old != null) {
            val mine = old.isDir && bw.tree.child(old, MARKER) != null
            if (mine) bw.tree.delete(old) else stageName = FileOps.uniqueName(bw.tree, stageParent, stageName)
        }
        val stage = bw.tree.mkdir(stageParent, stageName)
        val applied = LinkedHashSet<String>()
        try {
            bw.tree.createFile(stage, MARKER)
            val total = maxOf(sc.kept, 1L)
            var done = 0L

            suspend fun copyDir(src: Node, dst: Node, rel: String) {
                currentCoroutineContext().ensureActive()
                val kids = p.tree.children(src)
                val hasBuild = kids.any { !it.isDir && it.name in BUILD_FILES }
                for (c in kids) {
                    val r = if (rel.isEmpty()) c.name else rel + "/" + c.name
                    val skip = (optimize && classify(r, c.name, c.isDir, hasBuild) != null) || globs.any { it.matches(r, c.isDir) }
                    if (skip) continue
                    if (c.isDir) {
                        val d = bw.tree.mkdir(dst, c.name)
                        copyDir(c, d, r)
                    } else if (isGradleFile(c)) {
                        val raw = p.tree.openIn(c).use { it.readBytes() }
                        val text = raw.toString(Charsets.UTF_8)
                        val kts = c.name.endsWith(".kts")
                        var t2 = text
                        val a1 = GradleTransforms.removeAbiSplits(t2)
                        if (a1.second) {
                            t2 = a1.first
                            applied.add("ABI splits removed in $r")
                        }
                        if (optimizeGradle && !sc.native && text.contains("com.android.application")) {
                            val a2 = GradleTransforms.enableShrink(t2, kts)
                            if (a2.second) {
                                t2 = a2.first
                                applied.add("R8 + resource shrinking enabled in $r")
                            }
                        }
                        val outBytes = if (t2 == text) raw else t2.toByteArray(Charsets.UTF_8)
                        val f = bw.tree.createFile(dst, c.name)
                        bw.tree.openOut(f).use { it.write(outBytes) }
                        done += outBytes.size
                    } else {
                        val f = bw.tree.createFile(dst, c.name)
                        p.tree.openIn(c).use { i ->
                            bw.tree.openOut(f).use { w ->
                                val buf = ByteArray(64 * 1024)
                                while (true) {
                                    val n = i.read(buf)
                                    if (n < 0) break
                                    w.write(buf, 0, n)
                                    done += n
                                    currentCoroutineContext().ensureActive()
                                    ctx.progress((done.toFloat() / total).coerceIn(0f, 1f) * 0.5f, "Staging " + c.name)
                                }
                            }
                        }
                    }
                }
            }

            copyDir(pn, stage, "")
            ctx.progress(0.5f, "Creating ZIP...")
            val zipRes = ZipEngine.createFrom(
                bw.tree, stage, bw.segs.dropLast(1) + stageName, o, emptyList(), listOf(MARKER),
                overwrite, false, ctx, Deflater.DEFAULT_COMPRESSION, name
            )
            val appliedArr = JSONArray()
            for (a in applied) appliedArr.put(a)
            rep.put("dry_run", false)
            rep.put("success", true)
            rep.put("applied", appliedArr)
            rep.put("zip", zipRes)
            rep.put("output", zipRes.optString("output"))
            rep.put("files", zipRes.optInt("files"))
            rep.put("size", zipRes.optLong("size"))
            rep.put("staging", if (keepStaging) "BuildWorkspace/$stageName" else "removed after zipping")
            return rep
        } finally {
            withContext(NonCancellable) {
                if (!keepStaging) bw.tree.delete(stage)
            }
        }
    }
}
