package app.claudefilebridge

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Secrets (device token, channel key, GitHub token) encrypted with an Android Keystore AES key. */
class SecretStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("fb_secrets", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        (ks.getKey("fb_master", null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder("fb_master", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    fun put(name: String, value: String?) {
        val e = sp.edit()
        if (value == null) {
            e.remove(name)
        } else {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val ct = c.doFinal(value.toByteArray(Charsets.UTF_8))
            e.putString(name, Base64.encodeToString(c.iv + ct, Base64.NO_WRAP))
        }
        e.apply()
    }

    fun get(name: String): String? {
        val s = sp.getString(name, null) ?: return null
        return try {
            val raw = Base64.decode(s, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences
    private lateinit var secrets: SecretStore
    lateinit var appCtx: Context
        private set

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        sp = appCtx.getSharedPreferences("fb", Context.MODE_PRIVATE)
        secrets = SecretStore(appCtx)
    }

    fun raw(): SharedPreferences = sp

    private fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    private fun put(k: String, v: String?) {
        val e = sp.edit()
        if (v == null) e.remove(k) else e.putString(k, v)
        e.apply()
    }
    private fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    private fun putB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    private fun i(k: String, d: Int): Int = sp.getInt(k, d)
    private fun putI(k: String, v: Int) { sp.edit().putInt(k, v).apply() }

    private fun randomId(n: Int): String {
        val a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        return buildString { repeat(n) { append(a[r.nextInt(a.length)]) } }
    }

    // ---- connection ----
    var backendUrl: String
        get() = s("backend", BuildConfig.DEFAULT_BACKEND_URL)
        set(v) { put("backend", v.trim().trimEnd('/')) }

    val deviceId: String
        get() {
            var v = s("device_id")
            if (v.isEmpty()) {
                v = "FB-" + randomId(8)
                put("device_id", v)
            }
            return v
        }

    var paired: Boolean
        get() = b("paired", false)
        set(v) { putB("paired", v) }

    var deviceToken: String?
        get() = secrets.get("device_token")
        set(v) { secrets.put("device_token", v) }

    var channelKey: String?
        get() = secrets.get("channel_key")
        set(v) { secrets.put("channel_key", v) }

    var channelTopic: String
        get() = s("channel_topic")
        set(v) { put("channel_topic", v) }

    var realtimeUrl: String
        get() = s("rt_url")
        set(v) { put("rt_url", v) }

    var realtimeKey: String
        get() = s("rt_key")
        set(v) { put("rt_key", v) }

    var skewMs: Long
        get() = sp.getLong("skew", 0L)
        set(v) { sp.edit().putLong("skew", v).apply() }

    var bridgeOn: Boolean
        get() = b("bridge_on", false)
        set(v) { putB("bridge_on", v) }

    var claudeEnabled: Boolean
        get() = b("claude_on", true)
        set(v) { putB("claude_on", v) }

    var emergency: Boolean
        get() = b("emergency", false)
        set(v) { putB("emergency", v) }

    fun clearPairing() {
        paired = false
        deviceToken = null
        channelKey = null
        channelTopic = ""
        realtimeUrl = ""
        realtimeKey = ""
        put("seen", "[]")
    }

    // ---- replay protection ----
    @Synchronized
    fun seen(id: String): Boolean {
        val a = JSONArray(s("seen", "[]"))
        for (n in 0 until a.length()) if (a.optString(n) == id) return true
        return false
    }

    @Synchronized
    fun markSeen(id: String) {
        val a = JSONArray(s("seen", "[]"))
        val l = ArrayList<String>()
        for (n in 0 until a.length()) l.add(a.optString(n))
        l.add(id)
        while (l.size > 300) l.removeAt(0)
        put("seen", JSONArray(l).toString())
    }

    // ---- storage roles: workspace, zip, apk, build ----
    fun treeUri(role: String): String? = s("tree_$role").ifEmpty { null }
    fun setTreeUri(role: String, uri: String?) { put("tree_$role", uri) }

    // ---- permissions & confirmations ----
    fun perm(p: Perm): Boolean = b("perm_${p.key}", p.defaultOn)
    fun setPerm(p: Perm, v: Boolean) { putB("perm_${p.key}", v) }

    fun permsJson(): JSONObject {
        val o = JSONObject()
        for (p in Perm.values()) o.put(p.key, perm(p))
        return o
    }

    var confirmOverwrite: Boolean
        get() = b("cf_over", true)
        set(v) { putB("cf_over", v) }

    var confirmUpload: Boolean
        get() = b("cf_up", true)
        set(v) { putB("cf_up", v) }

    var confirmMove: Boolean
        get() = b("cf_move", false)
        set(v) { putB("cf_move", v) }

    /** 0 = never ask. */
    var confirmLargeStorageMb: Int
        get() = i("cf_store", 500)
        set(v) { putI("cf_store", v) }

    var confirmLargeNetworkMb: Int
        get() = i("cf_net", 50)
        set(v) { putI("cf_net", v) }

    // ---- build provider (GitHub Actions); nothing is hardcoded ----
    var ghOwner: String
        get() = s("gh_owner")
        set(v) { put("gh_owner", v.trim()) }

    var ghRepo: String
        get() = s("gh_repo")
        set(v) { put("gh_repo", v.trim()) }

    var ghBranch: String
        get() = s("gh_branch", "main")
        set(v) { put("gh_branch", v.trim()) }

    var ghWorkflow: String
        get() = s("gh_workflow", "build.yml")
        set(v) { put("gh_workflow", v.trim()) }

    var ghZipPath: String
        get() = s("gh_zip", "project.zip")
        set(v) { put("gh_zip", v.trim().trimStart('/')) }

    var ghArtifact: String
        get() = s("gh_artifact")
        set(v) { put("gh_artifact", v.trim()) }

    var ghToken: String?
        get() = secrets.get("gh_token")
        set(v) { secrets.put("gh_token", v?.trim()?.ifEmpty { null }) }

    var lastBuildId: String
        get() = s("last_build")
        set(v) { put("last_build", v) }
}

/** Approximate network use today (only what this app sends/receives). */
object Usage {
    private fun day(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun up(n: Long) = add(true, n)
    fun down(n: Long) = add(false, n)

    @Synchronized
    private fun add(isUp: Boolean, n: Long) {
        if (n <= 0) return
        val sp = Prefs.raw()
        val d = day()
        val same = sp.getString("use_day", "") == d
        var up = if (same) sp.getLong("use_up", 0L) else 0L
        var down = if (same) sp.getLong("use_down", 0L) else 0L
        if (isUp) up += n else down += n
        sp.edit().putString("use_day", d).putLong("use_up", up).putLong("use_down", down).apply()
        BridgeState.usage.value = Pair(up, down)
    }

    fun today(): Pair<Long, Long> {
        val sp = Prefs.raw()
        return if (sp.getString("use_day", "") == day()) Pair(sp.getLong("use_up", 0L), sp.getLong("use_down", 0L)) else Pair(0L, 0L)
    }
}

/** Lightweight local operation history (metadata only, newest first, max 200). */
object ActivityLog {
    private val file: File by lazy { File(Prefs.appCtx.filesDir, "activity.json") }

    @Synchronized
    fun load() {
        try {
            if (!file.exists()) return
            val arr = JSONArray(file.readText())
            val out = ArrayList<Act>()
            for (n in 0 until arr.length()) {
                val o = arr.getJSONObject(n)
                out.add(Act(o.getLong("t"), o.getString("tool"), o.getBoolean("ok"), o.optString("st"), o.optLong("b"), o.optLong("ms"), o.optString("d"), o.optBoolean("r")))
            }
            BridgeState.activity.value = out
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun add(a: Act) {
        val list = (listOf(a) + BridgeState.activity.value).take(200)
        BridgeState.activity.value = list
        try {
            val arr = JSONArray()
            for (x in list) {
                arr.put(JSONObject().put("t", x.time).put("tool", x.tool).put("ok", x.ok).put("st", x.status).put("b", x.bytes).put("ms", x.ms).put("d", x.detail).put("r", x.remote))
            }
            file.writeText(arr.toString())
        } catch (e: Exception) {
        }
    }
}

/** Process-wide state observed by the UI and the foreground-service notification. */
object BridgeState {
    val conn = MutableStateFlow(Conn.STOPPED)
    val detail = MutableStateFlow("")
    val op = MutableStateFlow<OpInfo?>(null)
    val pending = MutableStateFlow<Pending?>(null)
    val usage = MutableStateFlow(Pair(0L, 0L))
    val activity = MutableStateFlow<List<Act>>(emptyList())
    val emergency = MutableStateFlow(false)
    val claudeEnabled = MutableStateFlow(true)
}
