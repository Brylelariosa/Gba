package app.claudefilebridge

import android.util.Base64
import android.util.Base64OutputStream
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.URLEncoder
import java.time.Instant
import java.util.zip.ZipInputStream

private class GhCfg(val owner: String, val repo: String, val branch: String, val workflow: String, val zipPath: String, val artifact: String) {
    val base: String get() = "/repos/$owner/$repo"
}

/** Streams {"message":..,"branch":..,"content":"<base64 of the ZIP>"} without ever holding the ZIP in memory. */
private class UploadBody(
    private val prefix: ByteArray,
    private val suffix: ByteArray,
    private val size: Long,
    private val open: () -> InputStream,
    private val onSent: (Long) -> Unit
) : RequestBody() {
    override fun contentType(): MediaType = "application/json".toMediaType()

    override fun contentLength(): Long = prefix.size + 4L * ((size + 2) / 3) + suffix.size

    override fun writeTo(sink: BufferedSink) {
        sink.write(prefix)
        val b64 = Base64OutputStream(object : OutputStream() {
            override fun write(b: Int) {
                sink.writeByte(b)
            }

            override fun write(b: ByteArray, off: Int, len: Int) {
                sink.write(b, off, len)
            }

            override fun close() {}
        }, Base64.NO_WRAP)
        open().use { i ->
            val buf = ByteArray(48 * 1024)
            var sent = 0L
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                b64.write(buf, 0, n)
                sent += n
                onSent(sent)
            }
        }
        b64.close()
        sink.write(suffix)
    }
}

/**
 * Build provider #1: GitHub Actions. The phone talks to GitHub directly with the user's own token
 * (stored encrypted on the phone); nothing goes through Supabase.
 */
object GitHub {
    private const val API = "https://api.github.com"
    private val JSON = "application/json".toMediaType()

    private fun cfg(): GhCfg {
        if (Prefs.ghOwner.isEmpty() || Prefs.ghRepo.isEmpty() || Prefs.ghToken.isNullOrEmpty()) {
            throw OpError("build_not_configured", "No build provider is set up. On the phone open FileBridge > Settings > Build provider (GitHub) and enter owner, repository and token.")
        }
        return GhCfg(Prefs.ghOwner, Prefs.ghRepo, Prefs.ghBranch.ifEmpty { "main" }, Prefs.ghWorkflow, Prefs.ghZipPath.ifEmpty { "project.zip" }, Prefs.ghArtifact)
    }

    private fun req(path: String): Request.Builder =
        Request.Builder().url(if (path.startsWith("http")) path else API + path)
            .header("Authorization", "Bearer " + (Prefs.ghToken ?: ""))
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "ClaudeFileBridge/" + BuildConfig.VERSION_NAME)

    private suspend fun call(b: Request.Builder): Response = Net.http.newCall(b.build()).await()

    private fun err(r: Response): OpError {
        val txt = try {
            r.body?.string() ?: ""
        } catch (e: Exception) {
            ""
        }
        val msg = try {
            JSONObject(txt).optString("message")
        } catch (e: Exception) {
            txt.take(200)
        }
        val hint = when (r.code) {
            401 -> " (token rejected)"
            403 -> " (token lacks permission, or rate limited)"
            404 -> " (repository, workflow or token scope not found)"
            else -> ""
        }
        return OpError("provider_error", "GitHub ${r.code}: ${msg.take(300)}$hint")
    }

    private suspend fun getJson(path: String): JSONObject =
        call(req(path).get()).use { r ->
            if (!r.isSuccessful) throw err(r)
            JSONObject(r.body?.string() ?: "{}")
        }

    private fun enc(path: String): String = path.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
    private fun q(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun resolveId(arg: String): String =
        arg.ifEmpty { Prefs.lastBuildId }.ifEmpty { throw OpError("no_build", "No build_id given and no earlier build was started from this phone") }

    suspend fun start(zipTree: Tree, zipNode: Node, display: String, note: String, ctx: OpCtx): JSONObject {
        val c = cfg()
        val size = zipNode.size
        if (size <= 0) throw OpError("empty", "The ZIP is empty or its size is unknown")
        if (size > 90L * 1024 * 1024) {
            throw OpError("too_large_for_provider", "The ZIP is ${fmtBytes(size)}; the GitHub contents API accepts roughly 90 MB at most. Use prepare_project_zip to shrink it.")
        }
        if (Prefs.confirmUpload) {
            if (!ctx.confirm("Upload to GitHub?", "Claude wants to upload $display (${fmtBytes(size)}) to ${c.owner}/${c.repo} and start a build.")) {
                throw OpError("declined", "The user declined the upload. Nothing was uploaded.")
            }
        } else {
            val mb = Prefs.confirmLargeNetworkMb
            if (mb > 0 && size > mb * 1024L * 1024L && !ctx.confirm("Large upload", "Upload ${fmtBytes(size)} to ${c.owner}/${c.repo}?")) {
                throw OpError("declined", "The user declined the upload. Nothing was uploaded.")
            }
        }
        ctx.progress(0f, "Checking repository...")
        val sha: String? = call(req("${c.base}/contents/${enc(c.zipPath)}?ref=${q(c.branch)}").get()).use { r ->
            if (r.code == 200) JSONObject(r.body?.string() ?: "{}").optString("sha").ifEmpty { null }
            else if (r.code == 404) null
            else throw err(r)
        }
        val head = JSONObject().put("message", ("FileBridge upload: " + note.ifEmpty { display }).take(200)).put("branch", c.branch)
        if (sha != null) head.put("sha", sha)
        val prefix = (head.toString().dropLast(1) + ",\"content\":\"").toByteArray(Charsets.UTF_8)
        val suffix = "\"}".toByteArray(Charsets.UTF_8)
        val body = UploadBody(prefix, suffix, size, { zipTree.openIn(zipNode) }) { sent ->
            ctx.progress((sent.toFloat() / size).coerceIn(0f, 1f), "Uploading ${fmtBytes(sent)} / ${fmtBytes(size)}")
        }
        val commitSha: String? = call(req("${c.base}/contents/${enc(c.zipPath)}").put(body)).use { r ->
            if (!r.isSuccessful) throw err(r)
            JSONObject(r.body?.string() ?: "{}").optJSONObject("commit")?.optString("sha")
        }

        ctx.progress(1f, "Waiting for the build to start...")
        val startedAt = System.currentTimeMillis()
        var runId: Long? = null
        if (commitSha != null) {
            for (n in 0 until 4) {
                val runs = getJson("${c.base}/actions/runs?head_sha=$commitSha&per_page=5").optJSONArray("workflow_runs")
                if (runs != null && runs.length() > 0) {
                    runId = runs.getJSONObject(0).getLong("id")
                    break
                }
                delay(2500L)
            }
        }
        if (runId == null && c.workflow.isNotEmpty()) {
            val dr = call(req("${c.base}/actions/workflows/${enc(c.workflow)}/dispatches").post(JSONObject().put("ref", c.branch).toString().toRequestBody(JSON)))
            dr.use { if (!it.isSuccessful) throw err(it) }
            for (n in 0 until 6) {
                delay(2500L)
                val runs = getJson("${c.base}/actions/runs?branch=${q(c.branch)}&event=workflow_dispatch&per_page=5").optJSONArray("workflow_runs")
                if (runs != null) {
                    for (k in 0 until runs.length()) {
                        val j = runs.getJSONObject(k)
                        val created = try {
                            Instant.parse(j.optString("created_at")).toEpochMilli()
                        } catch (e: Exception) {
                            0L
                        }
                        if (created >= startedAt - 20_000L) {
                            runId = j.getLong("id")
                            break
                        }
                    }
                }
                if (runId != null) break
            }
        }
        val id = runId ?: throw OpError(
            "build_not_started",
            "The ZIP was uploaded to ${c.owner}/${c.repo} but no workflow run appeared. Check that the workflow triggers on push or has workflow_dispatch."
        )
        Prefs.lastBuildId = id.toString()
        return jsonOf("build_id" to id.toString(), "uploaded" to display, "size" to size, "repo" to "${c.owner}/${c.repo}", "branch" to c.branch, "state" to "queued")
    }

    suspend fun status(arg: String): JSONObject {
        val c = cfg()
        val id = resolveId(arg)
        val run = getJson("${c.base}/actions/runs/$id")
        val jobs = getJson("${c.base}/actions/runs/$id/jobs?per_page=30").optJSONArray("jobs") ?: JSONArray()
        val js = JSONArray()
        for (k in 0 until jobs.length()) {
            val j = jobs.getJSONObject(k)
            js.put(jsonOf("id" to j.optLong("id"), "name" to j.optString("name"), "status" to j.optString("status"), "conclusion" to j.str("conclusion")))
        }
        return jsonOf(
            "build_id" to id,
            "status" to run.optString("status"),
            "conclusion" to run.str("conclusion"),
            "html_url" to run.optString("html_url"),
            "created_at" to run.optString("created_at"),
            "updated_at" to run.optString("updated_at"),
            "jobs" to js
        )
    }

    suspend fun logs(arg: String, tail: Int, jobFilter: String): JSONObject {
        val c = cfg()
        val id = resolveId(arg)
        val jobs = getJson("${c.base}/actions/runs/$id/jobs?per_page=30").optJSONArray("jobs") ?: JSONArray()
        var pick: JSONObject? = null
        for (k in 0 until jobs.length()) {
            val j = jobs.getJSONObject(k)
            if (jobFilter.isNotEmpty()) {
                if (j.optString("name").contains(jobFilter, true)) {
                    pick = j
                    break
                }
            } else if (j.optString("conclusion") == "failure") {
                pick = j
                break
            }
        }
        if (pick == null && jobs.length() > 0) pick = jobs.getJSONObject(jobs.length() - 1)
        val job = pick ?: return jsonOf("build_id" to id, "log" to "", "note" to "No jobs yet")
        val ring = ArrayDeque<String>()
        call(req("${c.base}/actions/jobs/${job.getLong("id")}/logs").get()).use { r ->
            if (r.code == 404 || r.code == 410) {
                return jsonOf("build_id" to id, "job" to job.optString("name"), "log" to "", "note" to "Logs are not available yet")
            }
            if (!r.isSuccessful) throw err(r)
            r.body!!.byteStream().bufferedReader().useLines { seq ->
                for (line in seq) {
                    ring.addLast(line.take(1000))
                    if (ring.size > tail) ring.removeFirst()
                }
            }
        }
        return jsonOf(
            "build_id" to id,
            "job" to job.optString("name"),
            "conclusion" to job.str("conclusion"),
            "lines" to ring.size,
            "log" to ring.joinToString("\n").takeLast(60_000)
        )
    }

    suspend fun cancel(arg: String): JSONObject {
        val c = cfg()
        val id = resolveId(arg)
        call(req("${c.base}/actions/runs/$id/cancel").post("".toRequestBody(null))).use { r ->
            if (r.code == 409) throw OpError("not_cancellable", "The run already finished or cannot be cancelled")
            if (!r.isSuccessful) throw err(r)
        }
        return jsonOf("build_id" to id, "cancel_requested" to true)
    }

    /** Streams the artifact ZIP and writes only the .apk files into the APK folder (no temp copy of the whole artifact). */
    suspend fun download(arg: String, outPath: String, ctx: OpCtx): JSONObject {
        val c = cfg()
        val id = resolveId(arg)
        val arts = getJson("${c.base}/actions/runs/$id/artifacts?per_page=30").optJSONArray("artifacts") ?: JSONArray()
        var art: JSONObject? = null
        for (k in 0 until arts.length()) {
            val a = arts.getJSONObject(k)
            if (a.optBoolean("expired")) continue
            if (c.artifact.isEmpty() || a.optString("name") == c.artifact) {
                art = a
                break
            }
        }
        val a = art ?: throw OpError("no_artifact", "This build has no downloadable artifact yet (has it finished, and does the workflow upload one?)")
        val size = a.optLong("size_in_bytes")
        val mb = Prefs.confirmLargeNetworkMb
        if (mb > 0 && size > mb * 1024L * 1024L && !ctx.confirm("Large download", "Download ${fmtBytes(size)} from GitHub?")) {
            throw OpError("declined", "The user declined the download.")
        }
        val o = Workspace.loc(outPath)
        val dir = o.tree.ensureDir(o.segs)
        Space.require(o.tree, size * 2)
        val saved = JSONArray()
        var partial: Node? = null
        try {
            call(req(a.getString("archive_download_url")).get()).use { r ->
                if (!r.isSuccessful) throw err(r)
                ZipInputStream(r.body!!.byteStream()).use { zin ->
                    val buf = ByteArray(64 * 1024)
                    var got = 0L
                    while (true) {
                        val e = zin.nextEntry ?: break
                        val leaf = e.name.substringAfterLast('/')
                        if (e.isDirectory || !leaf.lowercase().endsWith(".apk")) continue
                        val name = FileOps.uniqueName(o.tree, dir, leaf)
                        val f = o.tree.createFile(dir, name)
                        partial = f
                        var n = 0L
                        o.tree.openOut(f).use { out ->
                            while (true) {
                                val k = zin.read(buf)
                                if (k < 0) break
                                out.write(buf, 0, k)
                                n += k
                                got += k
                                currentCoroutineContext().ensureActive()
                                ctx.progress(if (size > 0) (got.toFloat() / size).coerceIn(0f, 1f) else null, name)
                            }
                        }
                        partial = null
                        Usage.down(n)
                        saved.put(jsonOf("name" to f.name, "size" to n))
                    }
                }
            }
        } catch (t: Throwable) {
            partial?.let { p -> withContext(NonCancellable) { o.tree.delete(p) } }
            throw t
        }
        if (saved.length() == 0) throw OpError("no_apk", "The build artifact contains no .apk file.")
        return jsonOf("build_id" to id, "saved" to saved, "folder" to o.display)
    }
}
