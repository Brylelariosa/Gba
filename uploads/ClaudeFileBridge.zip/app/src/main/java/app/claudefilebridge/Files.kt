package app.claudefilebridge

import android.net.Uri
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class Loc(val tree: Tree, val segs: List<String>, val display: String)

object Workspace {
    private val cache = HashMap<String, Tree>()

    private fun tree(role: String): Tree? {
        val u = Prefs.treeUri(role) ?: return null
        return synchronized(cache) { cache.getOrPut("$role|$u") { Tree(Prefs.appCtx, Uri.parse(u)) } }
    }

    fun hasWorkspace(): Boolean = Prefs.treeUri("workspace") != null

    /** Virtual path -> (tree, segments). ZIP/, APK/ and BuildWorkspace/ use their own folder when the user picked one. */
    fun loc(path: String): Loc {
        val segs = PathUtil.split(path)
        if (segs.isNotEmpty()) {
            val role = when (segs[0]) {
                "ZIP" -> "zip"
                "APK" -> "apk"
                "BuildWorkspace" -> "build"
                else -> null
            }
            if (role != null) {
                val t = tree(role)
                if (t != null) return Loc(t, segs.drop(1), PathUtil.join(segs))
            }
        }
        val t = tree("workspace")
            ?: throw OpError("workspace_not_set", "No Claude Workspace folder is selected on the phone yet (FileBridge > Settings > Storage).")
        return Loc(t, segs, PathUtil.join(segs))
    }
}

object Space {
    /** Cancels (before anything is touched) when the volume cannot hold [needed] bytes plus a safety margin. */
    fun require(t: Tree, needed: Long) {
        val free = t.freeBytes()
        if (needed + 32L * 1024 * 1024 > free) {
            throw OpError(
                "insufficient_storage",
                "Operation cancelled. Required: ${fmtBytes(needed)} Available: ${fmtBytes(free)} Nothing was modified.",
                jsonOf("required_bytes" to needed, "available_bytes" to free)
            )
        }
    }

    suspend fun guard(t: Tree, needed: Long, ctx: OpCtx, what: String) {
        require(t, needed)
        val mb = Prefs.confirmLargeStorageMb
        if (mb > 0 && needed > mb * 1024L * 1024L) {
            if (!ctx.confirm("Large storage use", "$what needs about ${fmtBytes(needed)} of space.")) {
                throw OpError("declined", "The user declined (large storage use). Nothing was modified.")
            }
        }
    }
}

class Counter {
    var files = 0
    var bytes = 0L
}

object FileOps {
    fun isoTime(ms: Long): String? {
        if (ms <= 0) return null
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(ms))
    }

    fun requireNode(l: Loc): Node = l.tree.find(l.segs) ?: throw OpError("not_found", "Not found: ${l.display.ifEmpty { "/" }}")

    fun uniqueName(t: Tree, parent: Node, name: String): String {
        val names = t.children(parent).map { it.name }.toHashSet()
        if (name !in names) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 1
        while (true) {
            val cand = "$base ($n)$ext"
            if (cand !in names) return cand
            n++
        }
    }

    fun sizeOf(t: Tree, n: Node): Long {
        if (!n.isDir) return maxOf(n.size, 0L)
        var s = 0L
        for (c in t.children(n)) s += sizeOf(t, c)
        return s
    }

    fun countFiles(t: Tree, n: Node): Int {
        if (!n.isDir) return 1
        var s = 0
        for (c in t.children(n)) s += countFiles(t, c)
        return s
    }

    private fun entry(c: Node, name: String): JSONObject = jsonOf(
        "name" to name,
        "type" to (if (c.isDir) "directory" else "file"),
        "size" to (if (c.isDir) null else c.size),
        "modified" to isoTime(c.modified)
    )

    // ---------------- list ----------------
    fun list(path: String, recursive: Boolean, limit: Int, cursor: String): JSONObject {
        val l = Workspace.loc(path)
        val dir = requireNode(l)
        if (!dir.isDir) throw OpError("not_a_directory", "Not a folder: ${l.display}")
        val offset = cursor.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val entries = JSONArray()
        var seen = 0
        var more = false
        val queue = ArrayDeque<Pair<Node, String>>()
        queue.add(Pair(dir, ""))
        loop@ while (queue.isNotEmpty()) {
            val (d, rel) = queue.removeFirst()
            val kids = l.tree.children(d).sortedWith(compareBy<Node>({ !it.isDir }, { it.name.lowercase() }))
            for (c in kids) {
                if (seen >= offset + limit) {
                    more = true
                    break@loop
                }
                val r = if (rel.isEmpty()) c.name else rel + "/" + c.name
                if (seen >= offset) entries.put(entry(c, r))
                seen++
                if (recursive && c.isDir) queue.add(Pair(c, r))
            }
        }
        val out = jsonOf(
            "path" to l.display,
            "entries" to entries,
            "count" to entries.length(),
            "next_cursor" to (if (more) (offset + limit).toString() else null)
        )
        if (l.display.isEmpty()) {
            val virt = JSONArray()
            for ((alias, role) in listOf("ZIP" to "zip", "APK" to "apk", "BuildWorkspace" to "build")) {
                if (Prefs.treeUri(role) != null) virt.put(alias)
            }
            out.put("virtual_folders", virt)
        }
        return out
    }

    // ---------------- info ----------------
    fun info(path: String): JSONObject {
        val l = Workspace.loc(path)
        val n = requireNode(l)
        return jsonOf(
            "path" to l.display,
            "name" to (if (l.segs.isEmpty()) "(root)" else n.name),
            "type" to (if (n.isDir) "directory" else "file"),
            "size" to (if (n.isDir) null else n.size),
            "modified" to isoTime(n.modified),
            "mime" to (if (n.isDir) null else n.mime),
            "children" to (if (n.isDir) l.tree.children(n).size else null)
        )
    }

    // ---------------- read (streamed line range) ----------------
    fun read(path: String, start: Int, max: Int): JSONObject {
        val l = Workspace.loc(path)
        val n = requireNode(l)
        if (n.isDir) throw OpError("is_directory", "That is a folder, not a file")
        val total = n.size
        return l.tree.openIn(n).use { raw ->
            val bis = BufferedInputStream(raw, 65536)
            bis.mark(8200)
            val head = ByteArray(8192)
            val got = bis.read(head)
            for (k in 0 until maxOf(got, 0)) {
                if (head[k] == 0.toByte()) throw OpError("binary_file", "Binary file: use get_file_info, or create_zip to move it around")
            }
            bis.reset()
            val r = BufferedReader(InputStreamReader(bis, Charsets.UTF_8), 65536)
            val sb = StringBuilder()
            var line = 0
            var returned = 0
            var hasMore = false
            var chars = 0
            var truncated = false
            val countAll = total in 0L..(5L * 1024 * 1024)
            while (true) {
                val s = r.readLine() ?: break
                line++
                if (line < start) continue
                if (returned >= max || chars > 100_000) {
                    hasMore = true
                    if (!countAll) break else continue
                }
                val t = if (s.length > 4000) {
                    truncated = true
                    s.substring(0, 4000) + "..."
                } else s
                sb.append(t).append('\n')
                chars += t.length + 1
                returned++
            }
            jsonOf(
                "path" to l.display,
                "start_line" to start,
                "end_line" to (start + returned - 1),
                "lines_returned" to returned,
                "content" to sb.toString(),
                "has_more" to hasMore,
                "total_lines" to (if (countAll) line else null),
                "long_lines_truncated" to truncated,
                "size" to total
            )
        }
    }

    // ---------------- create folder ----------------
    fun createFolder(path: String): JSONObject {
        val l = Workspace.loc(path)
        if (l.segs.isEmpty()) throw OpError("invalid_path", "Give a folder path")
        val ex = l.tree.find(l.segs)
        if (ex != null) {
            if (!ex.isDir) throw OpError("exists", "A file with that name already exists")
            return jsonOf("path" to l.display, "created" to false)
        }
        l.tree.ensureDir(l.segs)
        return jsonOf("path" to l.display, "created" to true)
    }

    // ---------------- write ----------------
    suspend fun write(path: String, content: String, overwrite: Boolean, createParents: Boolean, ctx: OpCtx): JSONObject {
        val l = Workspace.loc(path)
        if (l.segs.isEmpty()) throw OpError("invalid_path", "Give a file path")
        val bytes = content.toByteArray(Charsets.UTF_8)
        if (bytes.size > 3_000_000) throw OpError("too_large", "Content is too large for write_file")
        val parentSegs = l.segs.dropLast(1)
        val parent = if (createParents) l.tree.ensureDir(parentSegs)
        else l.tree.find(parentSegs) ?: throw OpError("not_found", "Parent folder does not exist")
        val name = l.segs.last()
        val existing = l.tree.child(parent, name)
        if (existing != null) {
            if (existing.isDir) throw OpError("is_directory", "A folder with that name exists")
            if (!overwrite) throw OpError("exists", "File exists. Pass overwrite=true to replace it.", jsonOf("path" to l.display))
            if (Prefs.confirmOverwrite && !ctx.confirm("Overwrite file?", "Claude wants to replace ${l.display} (${fmtBytes(existing.size)}) with ${fmtBytes(bytes.size.toLong())}.")) {
                throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
            }
        }
        Space.require(l.tree, bytes.size.toLong())
        val tmpName = "$name.fbtmp"
        l.tree.child(parent, tmpName)?.let { l.tree.delete(it) }
        val tmp = l.tree.createFile(parent, tmpName)
        try {
            l.tree.openOut(tmp).use { it.write(bytes) }
        } catch (e: Exception) {
            l.tree.delete(tmp)
            throw if (e is OpError) e else OpError("storage_error", "Write failed: ${e.message}")
        }
        if (existing != null && !l.tree.delete(existing)) {
            l.tree.delete(tmp)
            throw OpError("storage_error", "Could not replace the existing file")
        }
        l.tree.rename(tmp, name) ?: throw OpError("storage_error", "Saved as $tmpName but renaming failed")
        return jsonOf("path" to l.display, "size" to bytes.size, "overwritten" to (existing != null))
    }

    // ---------------- streaming copy ----------------
    private suspend fun pump(inp: InputStream, out: OutputStream, ctx: OpCtx, c: Counter, total: Long, label: String) {
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = inp.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            c.bytes += n
            currentCoroutineContext().ensureActive()
            ctx.progress(if (total > 0) (c.bytes.toFloat() / total).coerceIn(0f, 1f) else null, label)
        }
    }

    private suspend fun copyFileTo(st: Tree, sn: Node, dt: Tree, parent: Node, name: String, existing: Node?, ctx: OpCtx, c: Counter, total: Long): Node {
        val tmpName = if (existing != null) "$name.fbtmp" else name
        if (existing != null) dt.child(parent, tmpName)?.let { dt.delete(it) }
        val out = dt.createFile(parent, tmpName)
        try {
            st.openIn(sn).use { i -> dt.openOut(out).use { o -> pump(i, o, ctx, c, total, sn.name) } }
        } catch (e: Throwable) {
            withContext(NonCancellable) { dt.delete(out) }
            throw e
        }
        c.files++
        if (existing == null) return out
        if (!dt.delete(existing)) {
            dt.delete(out)
            throw OpError("storage_error", "Could not replace the existing file")
        }
        return dt.rename(out, name) ?: throw OpError("storage_error", "Copied as $tmpName but renaming failed")
    }

    private suspend fun copyTree(st: Tree, sn: Node, dt: Tree, dn: Node, ctx: OpCtx, c: Counter, total: Long) {
        for (ch in st.children(sn)) {
            currentCoroutineContext().ensureActive()
            if (ch.isDir) {
                val d = dt.mkdir(dn, ch.name)
                copyTree(st, ch, dt, d, ctx, c, total)
            } else {
                copyFileTo(st, ch, dt, dn, ch.name, null, ctx, c, total)
            }
        }
    }

    private fun isInside(a: Loc, b: Loc): Boolean =
        a.tree.treeUri == b.tree.treeUri && b.segs.size >= a.segs.size && b.segs.subList(0, a.segs.size) == a.segs

    suspend fun copy(src: String, dst: String, overwrite: Boolean, ctx: OpCtx): JSONObject {
        val a = Workspace.loc(src)
        val b = Workspace.loc(dst)
        val sn = requireNode(a)
        if (b.segs.isEmpty()) throw OpError("invalid_path", "Destination must be a path")
        if (sn.isDir && isInside(a, b)) throw OpError("invalid_path", "Cannot copy a folder into itself")
        val parent = b.tree.ensureDir(b.segs.dropLast(1))
        val name = b.segs.last()
        val existing = b.tree.child(parent, name)
        if (existing != null) {
            if (sn.isDir || existing.isDir) throw OpError("exists", "Destination already exists")
            if (!overwrite) throw OpError("exists", "Destination exists. Pass overwrite=true to replace it.")
            if (Prefs.confirmOverwrite && !ctx.confirm("Overwrite file?", "Claude wants to replace ${b.display} with a copy of ${a.display}.")) {
                throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
            }
        }
        val total = sizeOf(a.tree, sn)
        Space.guard(b.tree, total, ctx, "Copying ${a.display}")
        val c = Counter()
        if (sn.isDir) {
            val d = b.tree.mkdir(parent, name)
            try {
                copyTree(a.tree, sn, b.tree, d, ctx, c, total)
            } catch (e: Throwable) {
                withContext(NonCancellable) { b.tree.delete(d) }
                throw e
            }
        } else {
            copyFileTo(a.tree, sn, b.tree, parent, name, existing, ctx, c, total)
        }
        return jsonOf("source" to a.display, "destination" to b.display, "files" to c.files, "bytes" to c.bytes, "size" to c.bytes)
    }

    // ---------------- move / rename ----------------
    suspend fun move(src: String, dst: String, overwrite: Boolean, ctx: OpCtx): JSONObject {
        val a = Workspace.loc(src)
        val b = Workspace.loc(dst)
        if (a.segs.isEmpty()) throw OpError("invalid_path", "Refusing to move a root folder")
        val sn = requireNode(a)
        if (b.segs.isEmpty()) throw OpError("invalid_path", "Destination must be a path")
        if (sn.isDir && isInside(a, b)) throw OpError("invalid_path", "Cannot move a folder into itself")
        val dparent = b.tree.ensureDir(b.segs.dropLast(1))
        val name = b.segs.last()
        val existing = b.tree.child(dparent, name)
        if (existing != null) {
            if (existing.isDir || sn.isDir) throw OpError("exists", "Destination already exists")
            if (!overwrite) throw OpError("exists", "Destination exists. Pass overwrite=true to replace it.")
            if (Prefs.confirmOverwrite && !ctx.confirm("Overwrite file?", "Claude wants to replace ${b.display} with ${a.display}.")) {
                throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
            }
        }
        if (Prefs.confirmMove && !ctx.confirm("Move?", "Claude wants to move ${a.display} to ${b.display}.")) {
            throw OpError("declined", "The user declined the move.")
        }
        val sparent = a.tree.find(a.segs.dropLast(1)) ?: throw OpError("not_found", "Source folder not found")
        if (a.tree.treeUri == b.tree.treeUri && sparent.docId == dparent.docId && sn.name == name) {
            return jsonOf("source" to a.display, "destination" to b.display, "moved" to false)
        }
        if (existing != null && !b.tree.delete(existing)) throw OpError("storage_error", "Could not replace the destination file")
        if (a.tree.treeUri == b.tree.treeUri) {
            var cur: Node? = sn
            if (sparent.docId != dparent.docId) cur = a.tree.move(sn, sparent, dparent)
            if (cur != null) {
                if (cur.name != name) {
                    cur = a.tree.rename(cur, name)
                        ?: throw OpError("partial_move", "Moved to the new folder but could not rename it to '$name'")
                }
                return jsonOf("source" to a.display, "destination" to b.display, "moved" to true)
            }
        }
        // Fallback: copy then delete (only after the copy fully succeeded).
        val total = sizeOf(a.tree, sn)
        Space.guard(b.tree, total, ctx, "Moving ${a.display}")
        val c = Counter()
        if (sn.isDir) {
            val d = b.tree.mkdir(dparent, name)
            try {
                copyTree(a.tree, sn, b.tree, d, ctx, c, total)
            } catch (e: Throwable) {
                withContext(NonCancellable) { b.tree.delete(d) }
                throw e
            }
        } else {
            copyFileTo(a.tree, sn, b.tree, dparent, name, null, ctx, c, total)
        }
        if (!a.tree.delete(sn)) throw OpError("partial_move", "Copied to ${b.display} but could not remove the original")
        return jsonOf("source" to a.display, "destination" to b.display, "moved" to true, "files" to c.files, "bytes" to c.bytes)
    }

    // ---------------- delete ----------------
    suspend fun delete(path: String, recursive: Boolean, ctx: OpCtx): JSONObject {
        val l = Workspace.loc(path)
        if (l.segs.isEmpty()) throw OpError("invalid_path", "Refusing to delete a root folder")
        val n = requireNode(l)
        var files = 0
        if (n.isDir) {
            if (l.tree.children(n).isNotEmpty() && !recursive) {
                throw OpError("not_empty", "Folder is not empty. Pass recursive=true to delete it and everything inside.")
            }
            files = countFiles(l.tree, n)
        }
        val what = if (n.isDir) "the folder ${l.display} ($files files)" else "${l.display} (${fmtBytes(n.size)})"
        if (!ctx.confirm("Delete from your phone?", "Claude wants to permanently delete $what.")) {
            throw OpError("declined", "The user declined the deletion. Nothing was deleted.")
        }
        if (!l.tree.delete(n)) throw OpError("storage_error", "Could not delete ${l.display}")
        return jsonOf("deleted" to l.display, "type" to (if (n.isDir) "directory" else "file"), "files" to files)
    }
}
