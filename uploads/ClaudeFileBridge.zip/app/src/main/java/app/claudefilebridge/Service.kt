package app.claudefilebridge

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.File

object Notifier {
    const val CH_STATUS = "bridge_status"
    const val CH_CONFIRM = "bridge_confirm"
    const val ID_STATUS = 41
    const val ID_CONFIRM = 42
    const val ACT_ALLOW = "app.claudefilebridge.ALLOW"
    const val ACT_DENY = "app.claudefilebridge.DENY"

    fun init(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val st = NotificationChannel(CH_STATUS, "Bridge status", NotificationManager.IMPORTANCE_LOW)
        st.setShowBadge(false)
        nm.createNotificationChannel(st)
        nm.createNotificationChannel(NotificationChannel(CH_CONFIRM, "Confirmations", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun flags(): Int = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    fun statusText(): String {
        val o = BridgeState.op.value
        if (o != null) {
            val p = o.progress
            return if (p != null) o.tool + " " + (p * 100).toInt() + "%" else o.tool
        }
        if (BridgeState.emergency.value) return "Emergency stop active (tap to resume)"
        if (!BridgeState.claudeEnabled.value) return "Claude disabled"
        return when (BridgeState.conn.value) {
            Conn.CONNECTED -> "Connected, idle"
            Conn.POLLING -> "Connected (polling), idle"
            Conn.CONNECTING -> "Connecting..."
            Conn.OFFLINE -> "Offline: waiting for network"
            Conn.UNPAIRED -> "Not paired"
            Conn.STOPPED -> "Stopped"
        }
    }

    fun status(ctx: Context): Notification {
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags())
        val stop = PendingIntent.getService(ctx, 1, Intent(ctx, BridgeService::class.java).setAction(BridgeService.ACTION_STOP), flags())
        val emg = PendingIntent.getService(ctx, 2, Intent(ctx, BridgeService::class.java).setAction(BridgeService.ACTION_EMERGENCY), flags())
        return NotificationCompat.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Claude FileBridge")
            .setContentText(statusText())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .addAction(0, "Emergency stop", emg)
            .build()
    }

    fun confirm(p: Pending) {
        val ctx = Prefs.appCtx
        fun pi(code: Int, action: String): PendingIntent =
            PendingIntent.getBroadcast(ctx, code, Intent(ctx, ActionReceiver::class.java).setAction(action).putExtra("id", p.id), flags())
        val open = PendingIntent.getActivity(ctx, 3, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags())
        val n = NotificationCompat.Builder(ctx, CH_CONFIRM)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(p.title)
            .setContentText(p.detail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(p.detail))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "Allow", pi(10, ACT_ALLOW))
            .addAction(0, "Deny", pi(11, ACT_DENY))
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(ID_CONFIRM, n)
        } catch (e: SecurityException) {
        }
    }

    fun clearConfirm() {
        try {
            NotificationManagerCompat.from(Prefs.appCtx).cancel(ID_CONFIRM)
        } catch (e: SecurityException) {
        }
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        when (intent.action) {
            Notifier.ACT_ALLOW -> Confirm.resolve(id, true)
            Notifier.ACT_DENY -> Confirm.resolve(id, false)
        }
    }
}

/**
 * Keeps the bridge alive while you use the phone for other things. Visible notification with Stop / Emergency stop.
 * Idle cost: one WebSocket heartbeat every ~25 s. No scanning, no indexing, no screenshots, no wake locks.
 */
class BridgeService : Service() {
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Bridge.stop()
            leave()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_EMERGENCY) Bridge.emergencyStop()
        enterForeground()
        if (!Prefs.paired) {
            leave()
            return START_NOT_STICKY
        }
        Bridge.start(applicationContext)
        if (watcher == null) {
            watcher = Ops.scope.launch {
                combine(BridgeState.conn, BridgeState.detail, BridgeState.op, BridgeState.emergency, BridgeState.claudeEnabled) { c, _, _, _, _ -> c }
                    .collect { c ->
                        if (c == Conn.UNPAIRED) {
                            leave()
                        } else {
                            try {
                                NotificationManagerCompat.from(this@BridgeService).notify(Notifier.ID_STATUS, Notifier.status(this@BridgeService))
                            } catch (e: SecurityException) {
                            }
                        }
                    }
            }
        }
        return START_STICKY
    }

    private fun enterForeground() {
        val n = Notifier.status(this)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(Notifier.ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(Notifier.ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(Notifier.ID_STATUS, n)
        }
    }

    private fun leave() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        watcher?.cancel()
        watcher = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "app.claudefilebridge.STOP"
        const val ACTION_EMERGENCY = "app.claudefilebridge.EMERGENCY"
    }
}

class FileBridgeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Notifier.init(this)
        ActivityLog.load()
        BridgeState.emergency.value = Prefs.emergency
        BridgeState.claudeEnabled.value = Prefs.claudeEnabled
        BridgeState.usage.value = Usage.today()
        // remove APK copies left over from installs
        try {
            File(cacheDir, "apk").deleteRecursively()
        } catch (e: Exception) {
        }
    }
}
