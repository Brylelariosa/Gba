// Claude FileBridge: remote MCP server + secure device relay (Supabase Edge Function "filebridge-mcp")
// Claude -> MCP tools -> command queue -> (signed wake over Realtime) -> Android app -> local file ops -> small result -> Claude.
// Files never pass through here; only tiny structured results do, and they are purged once delivered.
import { createClient } from "npm:@supabase/supabase-js@2";

const VERSION = "1.0.0";
const FN = "filebridge-mcp";
const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SB_ANON = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
const db = createClient(SB_URL, SB_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const te = new TextEncoder();

type Json = Record<string, unknown>;
interface Dev { device_id: string; name: string; channel_id: string; channel_key: string; status: string; state: Json | null; last_seen_at: string | null; app_version: string | null }
const DEV_COLS = "device_id,name,channel_id,channel_key,status,state,last_seen_at,app_version";

// ---------- helpers ----------
const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "authorization, content-type, mcp-protocol-version, mcp-session-id, x-fb-device",
  "access-control-allow-methods": "GET, POST, DELETE, OPTIONS",
};
const json = (o: unknown, status = 200, h: Record<string, string> = {}) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS, ...h } });
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const hex = (b: ArrayBuffer) => Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, "0")).join("");
const sha256Hex = async (s: string) => hex(await crypto.subtle.digest("SHA-256", te.encode(s)));
async function hmacHex(key: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", te.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", k, te.encode(msg)));
}
const hexRand = (n: number) => hex(crypto.getRandomValues(new Uint8Array(n)).buffer);
function randToken(n = 32) {
  const b = crypto.getRandomValues(new Uint8Array(n));
  let s = "";
  for (const x of b) s += String.fromCharCode(x);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function safeEq(a: string, b: string) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const clipJson = (v: unknown, max: number) => { try { const s = JSON.stringify(v); return s && s.length <= max ? v : null; } catch { return null; } };

class ToolErr extends Error {
  code: string; extra?: Json;
  constructor(code: string, msg: string, extra?: Json) { super(msg); this.code = code; this.extra = extra; }
}

// ---------- argument validation (the phone re-validates everything) ----------
const str = (a: Json, k: string, max = 1024, req = true): string => {
  const v = a[k];
  if (v === undefined || v === null || v === "") { if (req) throw new ToolErr("invalid_argument", `'${k}' is required`); return ""; }
  if (typeof v !== "string" || v.length > max) throw new ToolErr("invalid_argument", `'${k}' must be a string (max ${max} chars)`);
  return v;
};
const int = (a: Json, k: string, def: number, min: number, max: number) => {
  const v = a[k];
  if (v === undefined || v === null) return def;
  if (typeof v !== "number" || !Number.isFinite(v)) throw new ToolErr("invalid_argument", `'${k}' must be a number`);
  return Math.min(max, Math.max(min, Math.trunc(v)));
};
const bool = (a: Json, k: string, def: boolean) => {
  const v = a[k];
  if (v === undefined || v === null) return def;
  if (typeof v !== "boolean") throw new ToolErr("invalid_argument", `'${k}' must be true or false`);
  return v;
};
const arr = (a: Json, k: string, maxItems = 50, maxLen = 200): string[] => {
  const v = a[k];
  if (v === undefined || v === null) return [];
  if (!Array.isArray(v) || v.length > maxItems || v.some((x) => typeof x !== "string" || x.length > maxLen)) throw new ToolErr("invalid_argument", `'${k}' must be an array of up to ${maxItems} short strings`);
  return v as string[];
};
const pth = (a: Json, k: string, req = true): string => {
  const p = str(a, k, 1024, req).replace(/\\/g, "/");
  const segs = p.split("/").filter((s) => s.length && s !== ".");
  if (segs.some((s) => s === ".." || s.includes("\0"))) throw new ToolErr("invalid_path", "Paths may not contain '..'");
  if (req && !segs.length) throw new ToolErr("invalid_path", `'${k}' is required`);
  return segs.join("/");
};

// ---------- tool catalogue (narrow, typed; no shell, no exec) ----------
interface ToolDef { name: string; title: string; description: string; props: Json; required: string[]; ro?: boolean; destructive?: boolean; open?: boolean; local?: boolean; wait: number }
const S = (description: string, extra: Json = {}) => ({ type: "string", description, ...extra });
const B = (description: string) => ({ type: "boolean", description });
const I = (description: string, minimum?: number, maximum?: number) => ({ type: "integer", description, ...(minimum !== undefined ? { minimum } : {}), ...(maximum !== undefined ? { maximum } : {}) });
const A = (description: string) => ({ type: "array", items: { type: "string" }, description });
const DEV_PROP = { device_id: S("Optional. Target phone (see list_devices). Defaults to the only paired phone.") };
const PATHS = "Paths are relative to the user's Claude Workspace folder; ZIP/, APK/ and BuildWorkspace/ are virtual folders for the output locations the user picked.";

const TOOLS: ToolDef[] = [
  { name: "list_devices", title: "List paired phones", local: true, ro: true, wait: 0, required: [], props: {}, description: "Lists paired FileBridge phones with last contact and the permissions the user has switched on. Call this first if unsure which operations are allowed." },
  { name: "list_files", title: "List files", ro: true, wait: 25000, required: [], props: { path: S("Folder to list. Empty = workspace root."), recursive: B("Include sub-folders. Default false."), limit: I("Entries per page, 1-500 (default 100).", 1, 500), cursor: S("next_cursor from the previous page.") }, description: `Lists files and folders (name, type, size, modified) with pagination. ${PATHS}` },
  { name: "read_file", title: "Read file", ro: true, wait: 25000, required: ["path"], props: { path: S("File to read."), start_line: I("First line (1-based). Default 1.", 1), max_lines: I("Lines to return, 1-2000 (default 200).", 1, 2000) }, description: `Reads a line range of a text file without loading it all into memory. Binary files are refused. ${PATHS}` },
  { name: "write_file", title: "Write file", destructive: true, wait: 25000, required: ["path", "content"], props: { path: S("File to write."), content: S("Full text content (UTF-8, up to 1.5M chars)."), overwrite: B("Replace an existing file. Default false (existing files are never silently overwritten; needs the Modify permission and may need on-device confirmation)."), create_parents: B("Create missing parent folders. Default true.") }, description: `Creates a text file inside the authorised workspace. ${PATHS}` },
  { name: "create_folder", title: "Create folder", wait: 25000, required: ["path"], props: { path: S("Folder to create (parents are created).") }, description: `Creates a folder. ${PATHS}` },
  { name: "copy_file", title: "Copy file or folder", wait: 50000, required: ["source", "destination"], props: { source: S("Existing file or folder."), destination: S("Exact target path (not 'into' a folder)."), overwrite: B("Replace an existing target file. Default false.") }, description: `Copies a file or folder (streamed, low memory). ${PATHS}` },
  { name: "move_file", title: "Move or rename", destructive: true, wait: 50000, required: ["source", "destination"], props: { source: S("Existing file or folder."), destination: S("Exact new path."), overwrite: B("Replace an existing target file. Default false.") }, description: `Moves or renames. Requires the Move permission, which is OFF by default. ${PATHS}` },
  { name: "delete_file", title: "Delete file or folder", destructive: true, wait: 50000, required: ["path"], props: { path: S("File or folder to delete."), recursive: B("Required to delete a non-empty folder. Default false.") }, description: `Deletes a file or folder. Disabled by default and always needs explicit confirmation on the phone; if the result says awaiting_confirmation or permission_denied, tell the user instead of retrying. ${PATHS}` },
  { name: "get_file_info", title: "Get file info", ro: true, wait: 25000, required: [], props: { path: S("File or folder. Empty = workspace root.") }, description: `Returns type, size, modified time and MIME type. ${PATHS}` },
  { name: "create_zip", title: "Create ZIP", wait: 50000, required: ["source", "output"], props: { source: S("Folder (or file) to archive."), output: S("Target ZIP path, e.g. ZIP/MyGame.zip."), include_patterns: A("Glob patterns to include (e.g. **/*.kt). Empty = everything."), exclude_patterns: A("Glob patterns to skip (e.g. build/, *.log, .git/). A pattern without '/' matches names at any depth; a trailing '/' matches folders."), overwrite: B("Replace an existing ZIP. Default false: a name like 'MyGame (1).zip' is used instead."), include_root_folder: B("Put everything under a top-level folder named after the source. Default false.") }, description: `Creates a ZIP locally on the phone with streaming (written to .tmp, then renamed; nothing is uploaded). Returns file count and size. ${PATHS}` },
  { name: "extract_zip", title: "Extract ZIP", destructive: true, wait: 50000, required: ["zip", "destination"], props: { zip: S("ZIP file to extract."), destination: S("Folder to extract into (created if needed)."), on_conflict: S("fail (default, rolls everything back), skip, rename or overwrite.", { enum: ["fail", "skip", "rename", "overwrite"] }) }, description: `Extracts a ZIP with path-traversal protection; nothing is written outside the destination. ${PATHS}` },
  { name: "prepare_project_zip", title: "Prepare project ZIP for build", wait: 50000, required: ["project", "output"], props: { project: S("Project folder."), output: S("Target ZIP, e.g. ZIP/MyGame-build.zip."), optimize: B("Leave out build artifacts, caches, VCS data and debug-only sources in the staged copy. Default true. Unknown files are always kept."), optimize_gradle: B("Also enable R8/resource shrinking in the staged copy when safe (never for native/NDK projects). Default false."), dry_run: B("Only return the optimisation report; change nothing."), keep_staging: B("Keep BuildWorkspace/<project>/ afterwards. Default false."), exclude_patterns: A("Extra glob patterns to leave out."), overwrite: B("Replace an existing ZIP. Default false.") }, description: `Stages a filtered copy in BuildWorkspace/<project>/ (the original is never touched), always keeps a universal APK setup (ABI splits are removed in the staged copy), and zips it. Returns an optimisation report. ${PATHS}` },
  { name: "start_build", title: "Start APK build", open: true, wait: 50000, required: [], props: { zip: S("Prepared ZIP to upload (see prepare_project_zip)."), project: S("Alternatively a project folder to prepare and upload."), provider: S("Build provider. Default github_actions.", { enum: ["github_actions"] }), note: S("Short label for the build.") }, description: "Uploads the project ZIP from the phone straight to the user's configured build provider (never through this server) and starts the build. Needs the Upload permission (OFF by default) and on-device confirmation." },
  { name: "get_build_status", title: "Get build status", ro: true, open: true, wait: 30000, required: [], props: { build_id: S("Defaults to the latest build.") }, description: "Returns the state of a build (queued, in_progress, success, failure) and its jobs." },
  { name: "get_build_logs", title: "Get build logs", ro: true, open: true, wait: 30000, required: [], props: { build_id: S("Defaults to the latest build."), tail_lines: I("Last N log lines, 1-2000 (default 200).", 1, 2000), job: S("Job name filter. Defaults to the failed (or last) job.") }, description: "Returns the tail of a build job's log." },
  { name: "cancel_build", title: "Cancel build", open: true, wait: 30000, required: [], props: { build_id: S("Defaults to the latest build.") }, description: "Cancels a running build." },
  { name: "download_build", title: "Download built APK", open: true, wait: 50000, required: [], props: { build_id: S("Defaults to the latest successful build."), output: S("Target folder. Default APK.") }, description: "Downloads the build's APK(s) directly onto the phone (universal APK, no ABI splits). Large downloads need on-device confirmation." },
  { name: "get_operation_status", title: "Get operation status", local: true, ro: true, wait: 0, required: ["operation_id"], props: { operation_id: S("operation_id from a result with status running / awaiting_confirmation."), wait_seconds: I("Seconds to wait for completion, 0-45 (default 20).", 0, 45) }, description: "Waits for / returns the outcome of a long-running operation." },
  { name: "cancel_operation", title: "Cancel operation", local: true, wait: 0, required: ["operation_id"], props: { operation_id: S("Operation to cancel.") }, description: "Asks the phone to cancel a pending or running operation. Nothing is deleted." },
];
const TOOL_LIST = TOOLS.map((t) => ({
  name: t.name, title: t.title, description: t.description,
  inputSchema: { type: "object", properties: { ...t.props, ...(t.local ? {} : DEV_PROP) }, required: t.required },
  annotations: { title: t.title, readOnlyHint: !!t.ro, destructiveHint: !!t.destructive, idempotentHint: !!t.ro, openWorldHint: !!t.open },
}));

const PERM: Record<string, string> = { list_files: "read", read_file: "read", get_file_info: "read", write_file: "create", create_folder: "create_folders", copy_file: "create", move_file: "move", delete_file: "delete", create_zip: "create_zip", extract_zip: "extract_zip", prepare_project_zip: "create_zip", start_build: "upload", get_build_status: "read", get_build_logs: "read", cancel_build: "upload", download_build: "create" };

function prep(name: string, a: Json): { args: Json; destructive: boolean } {
  switch (name) {
    case "list_files": return { args: { path: pth(a, "path", false), recursive: bool(a, "recursive", false), limit: int(a, "limit", 100, 1, 500), cursor: str(a, "cursor", 200, false) }, destructive: false };
    case "read_file": return { args: { path: pth(a, "path"), start_line: int(a, "start_line", 1, 1, 1e9), max_lines: int(a, "max_lines", 200, 1, 2000) }, destructive: false };
    case "write_file": {
      const c = a.content;
      if (typeof c !== "string") throw new ToolErr("invalid_argument", "'content' must be a string");
      if (c.length > 1_500_000) throw new ToolErr("too_large", "content is limited to 1.5M characters per call; split large files");
      const ow = bool(a, "overwrite", false);
      return { args: { path: pth(a, "path"), content: c, overwrite: ow, create_parents: bool(a, "create_parents", true) }, destructive: ow };
    }
    case "create_folder": return { args: { path: pth(a, "path") }, destructive: false };
    case "copy_file": { const ow = bool(a, "overwrite", false); return { args: { source: pth(a, "source"), destination: pth(a, "destination"), overwrite: ow }, destructive: ow }; }
    case "move_file": return { args: { source: pth(a, "source"), destination: pth(a, "destination"), overwrite: bool(a, "overwrite", false) }, destructive: true };
    case "delete_file": return { args: { path: pth(a, "path"), recursive: bool(a, "recursive", false) }, destructive: true };
    case "get_file_info": return { args: { path: pth(a, "path", false) }, destructive: false };
    case "create_zip": { const ow = bool(a, "overwrite", false); return { args: { source: pth(a, "source"), output: pth(a, "output"), include_patterns: arr(a, "include_patterns"), exclude_patterns: arr(a, "exclude_patterns"), overwrite: ow, include_root_folder: bool(a, "include_root_folder", false) }, destructive: ow }; }
    case "extract_zip": {
      const oc = str(a, "on_conflict", 16, false) || "fail";
      if (!["fail", "skip", "rename", "overwrite"].includes(oc)) throw new ToolErr("invalid_argument", "on_conflict must be fail, skip, rename or overwrite");
      return { args: { zip: pth(a, "zip"), destination: pth(a, "destination", false), on_conflict: oc }, destructive: oc === "overwrite" };
    }
    case "prepare_project_zip": { const ow = bool(a, "overwrite", false); return { args: { project: pth(a, "project"), output: pth(a, "output"), optimize: bool(a, "optimize", true), optimize_gradle: bool(a, "optimize_gradle", false), dry_run: bool(a, "dry_run", false), keep_staging: bool(a, "keep_staging", false), exclude_patterns: arr(a, "exclude_patterns"), overwrite: ow }, destructive: ow }; }
    case "start_build": {
      const zip = pth(a, "zip", false), project = pth(a, "project", false);
      if (!zip && !project) throw new ToolErr("invalid_argument", "Provide 'zip' (prepared ZIP) or 'project' (folder)");
      return { args: { zip, project, provider: str(a, "provider", 32, false) || "github_actions", note: str(a, "note", 120, false) }, destructive: false };
    }
    case "get_build_status": case "cancel_build": return { args: { build_id: str(a, "build_id", 64, false) }, destructive: false };
    case "get_build_logs": return { args: { build_id: str(a, "build_id", 64, false), tail_lines: int(a, "tail_lines", 200, 1, 2000), job: str(a, "job", 80, false) }, destructive: false };
    case "download_build": return { args: { build_id: str(a, "build_id", 64, false), output: pth(a, "output", false) || "APK" }, destructive: false };
  }
  throw new ToolErr("unknown_tool", `Unknown tool '${name}'`);
}

function precheck(dev: Dev, tool: string, args: Json) {
  const st = (dev.state ?? {}) as Json;
  if (st.emergency_stop === true) throw new ToolErr("emergency_stop", "The user pressed Emergency Stop on the phone; remote commands are paused until they resume.");
  if (st.claude_enabled === false) throw new ToolErr("claude_disabled", "The user switched 'Disable Claude' on in FileBridge. Ask them to re-enable it.");
  const perms = st.permissions as Record<string, boolean> | undefined;
  if (!perms) return;
  const need = [PERM[tool]];
  if (args.overwrite === true || args.on_conflict === "overwrite") need.push("modify");
  for (const p of need) {
    if (p && perms[p] === false) throw new ToolErr("permission_denied", `The '${p}' permission is OFF on the phone (Claude Permissions). Tell the user which permission to enable; do not retry.`, { permission: p });
  }
}

// ---------- device resolution, wake-up, wait ----------
async function resolveDevice(id?: string): Promise<Dev> {
  let q = db.from("filebridge_devices").select(DEV_COLS).eq("status", "active");
  if (id) q = q.eq("device_id", id);
  const { data } = await q.order("last_seen_at", { ascending: false, nullsFirst: false }).limit(5);
  if (!data?.length) throw new ToolErr("no_device", id ? `Device ${id} is not paired.` : "No phone is paired yet. Open Claude FileBridge on the phone and pair it first.");
  if (!id && data.length > 1) throw new ToolErr("device_ambiguous", "Several phones are paired; pass device_id (see list_devices).");
  return data[0] as unknown as Dev;
}

async function wake(dev: Dev, cmdId: string, expiresAt: string): Promise<number> {
  try {
    const ts = Math.floor(Date.now() / 1000);
    const exp = Math.floor(new Date(expiresAt).getTime() / 1000);
    const sig = await hmacHex(dev.channel_key, `${dev.device_id}.${cmdId}.${ts}.${exp}`);
    const r = await fetch(`${SB_URL}/realtime/v1/api/broadcast`, {
      method: "POST",
      headers: { "content-type": "application/json", apikey: SB_ANON || SB_KEY, authorization: `Bearer ${SB_KEY}` },
      body: JSON.stringify({ messages: [{ topic: `fb-${dev.channel_id}`, event: "wake", payload: { v: 1, did: dev.device_id, cid: cmdId, ts, exp, sig }, private: false }] }),
    });
    await r.body?.cancel();
    return r.status;
  } catch (e) {
    console.error("wake failed", String(e));
    return -1;
  }
}

const DONE = ["succeeded", "failed", "rejected", "cancelled", "expired"];
async function finalResult(id: string, st: string): Promise<Json> {
  const { data: r } = await db.from("filebridge_results").select("ok,result,error,error_code,duration_ms,consumed_at").eq("command_id", id).maybeSingle();
  if (!r) {
    if (st === "expired") return { ok: false, error: "expired", operation_id: id, message: "The command expired before the phone ran it. Nothing was changed." };
    if (st === "cancelled") return { ok: false, error: "cancelled", operation_id: id, message: "The operation was cancelled. Nothing was deleted." };
    return { ok: st === "succeeded", status: st, operation_id: id };
  }
  if (r.consumed_at) return { ok: !!r.ok, status: st, operation_id: id, note: "The result was already delivered earlier." };
  await db.from("filebridge_results").update({ result: null, consumed_at: new Date().toISOString() }).eq("command_id", id);
  const extra = (r.result && typeof r.result === "object" ? r.result : {}) as Json;
  if (r.ok) return { ...extra, ok: true, status: st, operation_id: id, duration_ms: r.duration_ms ?? undefined };
  return { ...extra, ok: false, status: st, operation_id: id, error: r.error_code ?? "failed", message: r.error ?? "Operation failed" };
}

async function awaitCommand(id: string, waitMs: number): Promise<Json> {
  const t0 = Date.now();
  let delay = 300;
  for (;;) {
    const { data: c } = await db.from("filebridge_commands").select("status,progress,created_at").eq("id", id).maybeSingle();
    if (!c) return { ok: false, error: "not_found", message: "Unknown operation_id." };
    if (DONE.includes(c.status)) return await finalResult(id, c.status);
    const age = Date.now() - new Date(c.created_at).getTime();
    if (c.status === "queued" && age > 12000) {
      await db.rpc("filebridge_expire_command", { p_id: id });
      return { ok: false, error: "device_unreachable", operation_id: id, message: "The phone did not pick up the command within 12 s, so it was cancelled and will not run later. Ask the user to open Claude FileBridge and check that the bridge is running (and not battery-restricted)." };
    }
    if (Date.now() - t0 >= waitMs) {
      return { ok: true, status: c.status, operation_id: id, progress: c.progress ?? undefined, hint: c.status === "awaiting_confirmation" ? "Waiting for the user to approve on the phone. Call get_operation_status to keep waiting." : "Still running. Call get_operation_status with this operation_id to keep waiting." };
    }
    await sleep(delay);
    delay = Math.min(1500, Math.round(delay * 1.25));
  }
}

async function runOnDevice(dev: Dev, def: ToolDef, args: Json, destructive: boolean): Promise<Json> {
  const { data, error } = await db.rpc("filebridge_enqueue", { p_device_id: dev.device_id, p_tool: def.name, p_args: args, p_destructive: destructive, p_ttl: destructive ? 45 : 90, p_nonce: hexRand(12) });
  const cmd: any = Array.isArray(data) ? data[0] : data;
  if (error || !cmd) {
    if (String(error?.message ?? "").includes("queue_full")) throw new ToolErr("queue_full", "The phone already has 10 pending operations. Wait for them to finish.");
    console.error("enqueue failed", error?.message);
    throw new ToolErr("internal", "Could not queue the command.");
  }
  const ws = await wake(dev, cmd.id, cmd.expires_at);
  console.log(JSON.stringify({ evt: "queued", tool: def.name, device: dev.device_id, wake: ws }));
  return await awaitCommand(cmd.id, def.wait);
}

async function listDevices(): Promise<Json> {
  const { data } = await db.from("filebridge_devices").select("device_id,name,status,app_version,state,last_seen_at,paired_at").neq("status", "revoked").order("paired_at");
  const now = Date.now();
  return {
    ok: true,
    devices: (data ?? []).map((d: any) => ({
      device_id: d.device_id, name: d.name, status: d.status, app_version: d.app_version,
      last_seen_seconds_ago: d.last_seen_at ? Math.round((now - new Date(d.last_seen_at).getTime()) / 1000) : null,
      claude_enabled: d.state?.claude_enabled ?? null, emergency_stop: d.state?.emergency_stop ?? false,
      permissions: d.state?.permissions ?? null, workspace: d.state?.workspace ?? null,
    })),
    note: "Idle phones only contact the server when connecting or when a command arrives, so a large last_seen_seconds_ago does not mean the phone is offline.",
  };
}

async function dispatchTool(def: ToolDef, a: Json): Promise<Json> {
  if (def.name === "list_devices") return await listDevices();
  if (def.name === "get_operation_status") {
    const id = str(a, "operation_id", 64);
    if (!UUID_RE.test(id)) throw new ToolErr("invalid_argument", "operation_id must come from an earlier result");
    return await awaitCommand(id, int(a, "wait_seconds", 20, 0, 45) * 1000);
  }
  if (def.name === "cancel_operation") {
    const id = str(a, "operation_id", 64);
    if (!UUID_RE.test(id)) throw new ToolErr("invalid_argument", "operation_id must come from an earlier result");
    const { data } = await db.rpc("filebridge_request_cancel", { p_id: id });
    if (data === "cancel_requested") {
      const { data: c } = await db.from("filebridge_commands").select("device_id").eq("id", id).maybeSingle();
      if (c) {
        const { data: d } = await db.from("filebridge_devices").select(DEV_COLS).eq("device_id", c.device_id).maybeSingle();
        if (d) await wake(d as unknown as Dev, id, new Date(Date.now() + 60000).toISOString());
      }
    }
    return { ok: data !== "not_found", status: data, operation_id: id };
  }
  const dev = await resolveDevice(str(a, "device_id", 20, false) || undefined);
  const { args, destructive } = prep(def.name, a);
  precheck(dev, def.name, args);
  return await runOnDevice(dev, def, args, destructive);
}

async function callTool(name: string, rawArgs: unknown) {
  const a = (rawArgs && typeof rawArgs === "object" ? rawArgs : {}) as Json;
  let out: Json;
  try {
    out = await dispatchTool(TOOLS.find((t) => t.name === name)!, a);
  } catch (e) {
    if (e instanceof ToolErr) out = { ok: false, error: e.code, message: e.message, ...(e.extra ?? {}) };
    else { console.error("tool error", String(e)); out = { ok: false, error: "internal", message: "Unexpected server error." }; }
  }
  return { content: [{ type: "text", text: JSON.stringify(out) }], isError: out.ok === false };
}

// ---------- MCP (Streamable HTTP, JSON responses) ----------
const SUPPORTED = ["2025-06-18", "2025-03-26", "2024-11-05"];
const INSTRUCTIONS = "Claude FileBridge lets you work with files on the user's Android phone. Paths are relative to the user's Claude Workspace folder; ZIP/, APK/ and BuildWorkspace/ are virtual folders for the user's chosen output locations. Every operation runs locally on the phone under permissions the user controls (move/delete/upload are OFF by default and may need on-device confirmation). If a result says permission_denied, claude_disabled, emergency_stop or awaiting_confirmation, tell the user and do not retry in a loop. Never overwrite unless overwrite=true is justified. Long operations return status=running with an operation_id: call get_operation_status to wait. Files are never uploaded to this server; only small structured results pass through it.";
const rpcOk = (id: unknown, result: unknown) => ({ jsonrpc: "2.0", id, result });
const rpcErr = (id: unknown, code: number, message: string) => ({ jsonrpc: "2.0", id: id ?? null, error: { code, message } });

async function dispatchRpc(m: any): Promise<unknown | null> {
  if (!m || typeof m !== "object" || m.jsonrpc !== "2.0" || typeof m.method !== "string") return rpcErr(m?.id, -32600, "Invalid request");
  const isNote = m.id === undefined || m.id === null;
  switch (m.method) {
    case "initialize": {
      const v = m.params?.protocolVersion;
      return rpcOk(m.id, { protocolVersion: SUPPORTED.includes(v) ? v : SUPPORTED[0], capabilities: { tools: { listChanged: false } }, serverInfo: { name: "claude-filebridge", title: "Claude FileBridge", version: VERSION }, instructions: INSTRUCTIONS });
    }
    case "ping": return isNote ? null : rpcOk(m.id, {});
    case "tools/list": return rpcOk(m.id, { tools: TOOL_LIST });
    case "tools/call": {
      const name = m.params?.name;
      if (typeof name !== "string" || !TOOLS.some((t) => t.name === name)) return rpcErr(m.id, -32602, `Unknown tool: ${String(name).slice(0, 60)}`);
      return rpcOk(m.id, await callTool(name, m.params?.arguments));
    }
    default: return isNote ? null : rpcErr(m.id, -32601, `Method not found: ${m.method.slice(0, 60)}`);
  }
}

async function handleMcp(req: Request): Promise<Response> {
  if (req.method === "GET") return new Response(null, { status: 405, headers: { allow: "POST, DELETE", ...CORS } });
  if (req.method === "DELETE") return new Response(null, { status: 200, headers: CORS });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  let body: any;
  try { body = await req.json(); } catch { return json(rpcErr(null, -32700, "Parse error"), 400); }
  if (Array.isArray(body)) {
    const out: unknown[] = [];
    for (const m of body.slice(0, 20)) { const r = await dispatchRpc(m); if (r) out.push(r); }
    return out.length ? json(out) : new Response(null, { status: 202, headers: CORS });
  }
  const r = await dispatchRpc(body);
  return r ? json(r) : new Response(null, { status: 202, headers: CORS });
}

async function verifyConnector(token: string | null): Promise<boolean> {
  if (!token || token.length > 128) return false;
  const { data } = await db.from("filebridge_config").select("connector_token_hash").eq("id", 1).maybeSingle();
  const h = data?.connector_token_hash as string | null | undefined;
  return !!h && safeEq(h, await sha256Hex(token));
}

// ---------- device protocol (per-device bearer token, HTTPS only) ----------
async function authDevice(req: Request): Promise<Dev | null> {
  const a = req.headers.get("authorization") ?? "";
  if (!a.toLowerCase().startsWith("bearer ")) return null;
  const tok = a.slice(7).trim();
  if (!tok.startsWith("fbd_") || tok.length > 128) return null;
  const { data } = await db.from("filebridge_devices").select(DEV_COLS).eq("token_hash", await sha256Hex(tok)).eq("status", "active").maybeSingle();
  return (data as unknown as Dev) ?? null;
}

async function signCommand(dev: Dev, c: any) {
  const iat = Math.floor(new Date(c.created_at).getTime() / 1000);
  const exp = Math.floor(new Date(c.expires_at).getTime() / 1000);
  const args_json = JSON.stringify(c.args ?? {});
  const sig = await hmacHex(dev.channel_key, `${c.id}|${dev.device_id}|${c.tool}|${c.nonce}|${iat}|${exp}|${c.destructive ? 1 : 0}|${args_json}`);
  return { id: c.id, device_id: dev.device_id, tool: c.tool, args_json, nonce: c.nonce, iat, exp, destructive: !!c.destructive, sig };
}

async function devPair(b: any): Promise<Response> {
  const code = String(b.pairing_code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  const id = String(b.device_id ?? "");
  if (!/^FB-[0-9A-Z]{8}$/.test(id) || code.length < 6) return json({ error: "bad_request" }, 400);
  const { data: chk, error: ce } = await db.rpc("filebridge_check_pairing", { p_hash: await sha256Hex(code) });
  if (ce) return json({ error: "internal" }, 500);
  if (chk !== "ok") return json({ error: `pairing_${chk}` }, chk === "locked" ? 429 : 403);
  const token = "fbd_" + randToken(32);
  const channel_id = hexRand(16);
  const channel_key = hexRand(32);
  const now = new Date().toISOString();
  const { error } = await db.from("filebridge_devices").upsert({
    device_id: id, name: String(b.name ?? "Android device").slice(0, 60), token_hash: await sha256Hex(token), channel_id, channel_key,
    status: "active", app_version: b.app_version ? String(b.app_version).slice(0, 32) : null, state: {}, paired_at: now, last_seen_at: now,
  }, { onConflict: "device_id" });
  if (error) { console.error("pair failed", error.message); return json({ error: "internal" }, 500); }
  console.log(JSON.stringify({ evt: "paired", device: id }));
  return json({ ok: true, device_id: id, device_token: token, channel_topic: `fb-${channel_id}`, channel_key, realtime_url: `wss://${new URL(SB_URL).host}/realtime/v1/websocket`, realtime_apikey: SB_ANON, server_time_ms: Date.now() });
}

async function handleDevice(req: Request, url: URL, path: string): Promise<Response> {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const raw = await req.text();
  if (raw.length > 600_000) return json({ error: "too_large" }, 413);
  let b: any = {};
  try { b = raw ? JSON.parse(raw) : {}; } catch { return json({ error: "bad_json" }, 400); }
  if (path === "/device/pair") return await devPair(b);
  const dev = await authDevice(req);
  if (!dev) return json({ error: "unauthorized" }, 401);
  const nowIso = () => new Date().toISOString();
  switch (path) {
    case "/device/hello": {
      const inflight = Array.isArray(b.inflight) ? b.inflight.filter((x: unknown) => typeof x === "string").slice(0, 20) : [];
      const { data, error } = await db.rpc("filebridge_hello", { p_device_id: dev.device_id, p_inflight: inflight, p_app_version: b.app_version ? String(b.app_version).slice(0, 32) : null });
      const st = clipJson(b.state, 4000);
      if (st && typeof st === "object") await db.from("filebridge_devices").update({ state: st }).eq("device_id", dev.device_id);
      return json({ ok: !error, server_time_ms: Date.now(), ...((data as Json) ?? {}) });
    }
    case "/device/poll": {
      const wait = Math.max(0, Math.min(25, Number(url.searchParams.get("wait") ?? 0) || 0));
      const t0 = Date.now();
      await db.from("filebridge_devices").update({ last_seen_at: nowIso() }).eq("device_id", dev.device_id);
      for (;;) {
        const { data: cmds } = await db.rpc("filebridge_claim", { p_device_id: dev.device_id, p_limit: 1 });
        const { data: canc } = await db.from("filebridge_commands").select("id").eq("device_id", dev.device_id).eq("cancel_requested", true).in("status", ["delivered", "running", "awaiting_confirmation"]);
        if ((cmds?.length ?? 0) > 0 || (canc?.length ?? 0) > 0 || Date.now() - t0 >= wait * 1000) {
          const out = [];
          for (const c of (cmds ?? []) as any[]) out.push(await signCommand(dev, c));
          return json({ ok: true, commands: out, cancel: (canc ?? []).map((x: any) => x.id), server_time_ms: Date.now() });
        }
        await sleep(1000);
      }
    }
    case "/device/progress": {
      if (!UUID_RE.test(String(b.command_id))) return json({ error: "bad_request" }, 400);
      const status = b.status === "awaiting_confirmation" ? "awaiting_confirmation" : "running";
      await db.from("filebridge_commands").update({ status, progress: clipJson(b.progress, 2000) }).eq("id", b.command_id).eq("device_id", dev.device_id).in("status", ["delivered", "running", "awaiting_confirmation"]);
      return json({ ok: true });
    }
    case "/device/result": {
      if (!UUID_RE.test(String(b.command_id))) return json({ error: "bad_request" }, 400);
      const result = b.result === undefined ? null : clipJson(b.result, 400_000);
      if (b.result !== undefined && b.result !== null && result === null) return json({ error: "result_too_large" }, 413);
      const { data, error } = await db.rpc("filebridge_finish", {
        p_id: b.command_id, p_device_id: dev.device_id, p_ok: b.ok === true, p_status: typeof b.status === "string" ? b.status : null, p_result: result,
        p_error: b.error ? String(b.error) : null, p_error_code: b.error_code ? String(b.error_code) : null,
        p_bytes: Number.isFinite(b.bytes) ? Math.trunc(b.bytes) : null, p_duration_ms: Number.isFinite(b.duration_ms) ? Math.trunc(b.duration_ms) : null,
      });
      if (error) { console.error("finish failed", error.message); return json({ error: "internal" }, 500); }
      return json({ ok: true, accepted: data === true });
    }
    case "/device/state": {
      const st = clipJson(b.state, 4000);
      if (!st || typeof st !== "object") return json({ error: "bad_request" }, 400);
      await db.from("filebridge_devices").update({ state: st, last_seen_at: nowIso() }).eq("device_id", dev.device_id);
      return json({ ok: true });
    }
    case "/device/unpair": {
      await db.from("filebridge_devices").update({ status: "revoked", token_hash: "revoked:" + hexRand(16), channel_key: hexRand(16) }).eq("device_id", dev.device_id);
      await db.from("filebridge_commands").update({ status: "cancelled", completed_at: nowIso(), args: {} }).eq("device_id", dev.device_id).eq("status", "queued");
      return json({ ok: true });
    }
    case "/device/connector/rotate": {
      const token = randToken(32);
      const { error } = await db.from("filebridge_config").update({ connector_token_hash: await sha256Hex(token), updated_at: nowIso() }).eq("id", 1);
      if (error) return json({ error: "internal" }, 500);
      return json({ ok: true, connector_url: `${SB_URL}/functions/v1/${FN}/c/${token}` });
    }
  }
  return json({ error: "not_found" }, 404);
}

// ---------- entry ----------
Deno.serve(async (req: Request) => {
  try {
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
    const url = new URL(req.url);
    let path = url.pathname;
    const i = path.indexOf(FN);
    if (i >= 0) path = path.slice(i + FN.length);
    path = path.replace(/\/+$/, "") || "/";
    if (path === "/health") return json({ ok: true, service: FN, version: VERSION });
    if (path.startsWith("/device/")) return await handleDevice(req, url, path);
    let token: string | null = null;
    const m = path.match(/^\/c\/([A-Za-z0-9_-]{20,128})$/);
    if (m) token = m[1];
    else if (path === "/") {
      const a = req.headers.get("authorization") ?? "";
      if (a.toLowerCase().startsWith("bearer ")) token = a.slice(7).trim();
    } else return json({ error: "not_found" }, 404);
    if (!(await verifyConnector(token))) return json({ error: "unauthorized" }, 401, { "www-authenticate": 'Bearer realm="filebridge"' });
    return await handleMcp(req);
  } catch (e) {
    console.error("unhandled", String(e));
    return json({ error: "internal" }, 500);
  }
});
