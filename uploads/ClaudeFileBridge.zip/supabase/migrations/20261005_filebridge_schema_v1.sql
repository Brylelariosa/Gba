-- Claude FileBridge backend (additive only, unique filebridge_* names). Already applied as migration "filebridge_schema_v1".

create table if not exists public.filebridge_config (
  id int primary key default 1 check (id = 1),
  connector_token_hash text,
  pairing_code_hash text,
  pairing_expires_at timestamptz,
  pairing_failures int not null default 0,
  pairing_locked_until timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
insert into public.filebridge_config (id) values (1) on conflict (id) do nothing;

create table if not exists public.filebridge_devices (
  device_id text primary key check (device_id ~ '^FB-[0-9A-Z]{8}$'),
  name text not null default 'Android device',
  token_hash text not null,
  channel_id text not null,
  channel_key text not null,
  status text not null default 'active' check (status in ('active','disabled','revoked')),
  app_version text,
  state jsonb not null default '{}'::jsonb,
  paired_at timestamptz not null default now(),
  last_seen_at timestamptz
);
create unique index if not exists filebridge_devices_token_hash_idx on public.filebridge_devices (token_hash);

create table if not exists public.filebridge_device_sessions (
  id uuid primary key default gen_random_uuid(),
  device_id text not null references public.filebridge_devices(device_id) on delete cascade,
  started_at timestamptz not null default now(),
  app_version text
);
create index if not exists filebridge_sessions_device_idx on public.filebridge_device_sessions (device_id, started_at desc);

create table if not exists public.filebridge_commands (
  id uuid primary key default gen_random_uuid(),
  device_id text not null references public.filebridge_devices(device_id) on delete cascade,
  tool text not null,
  args jsonb not null default '{}'::jsonb,
  destructive boolean not null default false,
  nonce text not null,
  status text not null default 'queued' check (status in ('queued','delivered','running','awaiting_confirmation','succeeded','failed','cancelled','rejected','expired')),
  progress jsonb,
  cancel_requested boolean not null default false,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  delivered_at timestamptz,
  completed_at timestamptz
);
create index if not exists filebridge_commands_dev_status_idx on public.filebridge_commands (device_id, status, created_at);

create table if not exists public.filebridge_results (
  command_id uuid primary key references public.filebridge_commands(id) on delete cascade,
  device_id text not null,
  ok boolean not null,
  result jsonb,
  error text,
  error_code text,
  bytes bigint,
  duration_ms int,
  consumed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.filebridge_history (
  id bigint generated always as identity primary key,
  device_id text not null,
  tool text not null,
  status text not null,
  size_bytes bigint,
  duration_ms int,
  detail text,
  created_at timestamptz not null default now()
);
create index if not exists filebridge_history_dev_idx on public.filebridge_history (device_id, created_at desc);

-- Row Level Security: nothing is reachable with anon/authenticated keys; only the Edge Function (service role) touches these tables.
do $$
declare t text;
begin
  foreach t in array array['filebridge_config','filebridge_devices','filebridge_device_sessions','filebridge_commands','filebridge_results','filebridge_history'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on table public.%I from anon, authenticated', t);
    execute format('drop policy if exists filebridge_deny_all on public.%I', t);
    execute format('create policy filebridge_deny_all on public.%I as restrictive for all to anon, authenticated using (false) with check (false)', t);
  end loop;
end $$;

-- Atomic helpers (service role only)
create or replace function public.filebridge_enqueue(p_device_id text, p_tool text, p_args jsonb, p_destructive boolean, p_ttl int, p_nonce text)
returns public.filebridge_commands
language plpgsql
set search_path = public
as $$
declare
  n int;
  r public.filebridge_commands;
begin
  update public.filebridge_commands
     set status = 'expired', completed_at = now(), args = '{}'::jsonb
   where device_id = p_device_id
     and ((status = 'queued' and expires_at <= now())
       or (status in ('delivered','running','awaiting_confirmation') and delivered_at < now() - interval '2 hours'));
  select count(*) into n from public.filebridge_commands
   where device_id = p_device_id and status in ('queued','delivered','running','awaiting_confirmation');
  if n >= 10 then
    raise exception 'queue_full';
  end if;
  insert into public.filebridge_commands (device_id, tool, args, destructive, nonce, expires_at)
  values (p_device_id, p_tool, coalesce(p_args, '{}'::jsonb), coalesce(p_destructive, false), p_nonce,
          now() + make_interval(secs => greatest(10, least(coalesce(p_ttl, 90), 600))))
  returning * into r;
  return r;
end $$;

create or replace function public.filebridge_claim(p_device_id text, p_limit int default 1)
returns setof public.filebridge_commands
language plpgsql
set search_path = public
as $$
begin
  return query
  with c as (
    select id from public.filebridge_commands
     where device_id = p_device_id and status = 'queued' and expires_at > now()
     order by created_at
     for update skip locked
     limit greatest(1, least(coalesce(p_limit, 1), 3))
  ), u as (
    update public.filebridge_commands f
       set status = 'delivered', delivered_at = now()
      from c
     where f.id = c.id
    returning f.*
  )
  select * from u;
end $$;

create or replace function public.filebridge_expire_command(p_id uuid)
returns void
language sql
set search_path = public
as $$
  update public.filebridge_commands
     set status = 'expired', completed_at = now(), args = '{}'::jsonb
   where id = p_id and status = 'queued';
$$;

create or replace function public.filebridge_request_cancel(p_id uuid)
returns text
language plpgsql
set search_path = public
as $$
declare s text;
begin
  select status into s from public.filebridge_commands where id = p_id for update;
  if s is null then return 'not_found'; end if;
  if s = 'queued' then
    update public.filebridge_commands set status = 'cancelled', completed_at = now(), args = '{}'::jsonb where id = p_id;
    return 'cancelled';
  elsif s in ('delivered','running','awaiting_confirmation') then
    update public.filebridge_commands set cancel_requested = true where id = p_id;
    return 'cancel_requested';
  end if;
  return s;
end $$;

create or replace function public.filebridge_finish(p_id uuid, p_device_id text, p_ok boolean, p_status text, p_result jsonb, p_error text, p_error_code text, p_bytes bigint, p_duration_ms int)
returns boolean
language plpgsql
set search_path = public
as $$
declare
  v_tool text;
  v_status text;
begin
  v_status := case when p_status in ('rejected','cancelled') then p_status when p_ok then 'succeeded' else 'failed' end;
  update public.filebridge_commands
     set status = v_status, completed_at = now(), args = '{}'::jsonb
   where id = p_id and device_id = p_device_id and status in ('delivered','running','awaiting_confirmation')
  returning tool into v_tool;
  if v_tool is null then return false; end if;
  insert into public.filebridge_results (command_id, device_id, ok, result, error, error_code, bytes, duration_ms)
  values (p_id, p_device_id, (p_ok and v_status = 'succeeded'), p_result, left(p_error, 2000), left(p_error_code, 64), p_bytes, p_duration_ms)
  on conflict (command_id) do nothing;
  insert into public.filebridge_history (device_id, tool, status, size_bytes, duration_ms, detail)
  values (p_device_id, v_tool, v_status, p_bytes, p_duration_ms, left(coalesce(p_error_code, ''), 64));
  return true;
end $$;

create or replace function public.filebridge_hello(p_device_id text, p_inflight text[], p_app_version text)
returns jsonb
language plpgsql
set search_path = public
as $$
declare v_expired int;
begin
  update public.filebridge_devices
     set last_seen_at = now(), app_version = coalesce(p_app_version, app_version)
   where device_id = p_device_id;
  -- Stale-command protection: destructive commands queued while the phone was away never run after reconnect.
  with u as (
    update public.filebridge_commands
       set status = 'expired', completed_at = now(), args = '{}'::jsonb
     where device_id = p_device_id and status = 'queued' and (destructive or expires_at <= now())
    returning 1
  )
  select count(*) into v_expired from u;
  -- In-flight commands the phone no longer knows about died with its previous process.
  update public.filebridge_commands
     set status = 'expired', completed_at = now(), args = '{}'::jsonb
   where device_id = p_device_id
     and status in ('delivered','running','awaiting_confirmation')
     and not (id::text = any (coalesce(p_inflight, '{}'::text[])));
  insert into public.filebridge_device_sessions (device_id, app_version) values (p_device_id, p_app_version);
  -- Retention (keeps the database tiny)
  delete from public.filebridge_history where created_at < now() - interval '30 days';
  delete from public.filebridge_results where created_at < now() - interval '1 hour';
  delete from public.filebridge_commands where created_at < now() - interval '7 days';
  delete from public.filebridge_device_sessions where started_at < now() - interval '30 days';
  return jsonb_build_object('expired_queued', v_expired);
end $$;

create or replace function public.filebridge_check_pairing(p_hash text)
returns text
language plpgsql
set search_path = public
as $$
declare c public.filebridge_config;
begin
  select * into c from public.filebridge_config where id = 1 for update;
  if not found then return 'invalid'; end if;
  if c.pairing_locked_until is not null and c.pairing_locked_until > now() then return 'locked'; end if;
  if c.pairing_code_hash is null or c.pairing_expires_at is null or c.pairing_expires_at < now() then return 'expired'; end if;
  if c.pairing_code_hash = p_hash then
    update public.filebridge_config
       set pairing_code_hash = null, pairing_expires_at = null, pairing_failures = 0, updated_at = now()
     where id = 1;
    return 'ok';
  end if;
  update public.filebridge_config
     set pairing_locked_until = case when pairing_failures + 1 >= 5 then now() + interval '10 minutes' else pairing_locked_until end,
         pairing_failures = case when pairing_failures + 1 >= 5 then 0 else pairing_failures + 1 end,
         updated_at = now()
   where id = 1;
  return 'invalid';
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'filebridge_enqueue(text,text,jsonb,boolean,int,text)',
    'filebridge_claim(text,int)',
    'filebridge_expire_command(uuid)',
    'filebridge_request_cancel(uuid)',
    'filebridge_finish(uuid,text,boolean,text,jsonb,text,text,bigint,int)',
    'filebridge_hello(text,text[],text)',
    'filebridge_check_pairing(text)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;
