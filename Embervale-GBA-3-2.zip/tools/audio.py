"""Sound effects (8-bit PCM @16384Hz) and PSG music data for Embervale."""
import math
import numpy as np

SR = 16384
RNG = np.random.RandomState(7)


def tt(sec):
    return np.arange(int(sec * SR)) / SR


def env(n, a=0.005, d=None, curve=3.0, sustain=0.0):
    x = np.arange(n) / SR
    tot = n / SR
    d = tot - a if d is None else d
    e = np.ones(n)
    att = np.minimum(1.0, x / max(a, 1e-4))
    dec = np.exp(-curve * np.clip(x - a, 0, None) / max(d, 1e-3))
    return att * (sustain + (1 - sustain) * dec)


def phase(freq):
    return np.cumsum(freq) / SR


def sine(f):
    return np.sin(2 * np.pi * phase(f))


def square(f, duty=0.5):
    p = phase(f) % 1.0
    return np.where(p < duty, 1.0, -1.0)


def saw(f):
    p = phase(f) % 1.0
    return 2 * p - 1


def tri(f):
    p = phase(f) % 1.0
    return 4 * np.abs(p - 0.5) - 1


def noise(n):
    return RNG.uniform(-1, 1, n)


def lowpass(x, fc):
    """one-pole lowpass with (possibly time varying) cutoff"""
    fc = np.broadcast_to(np.asarray(fc, dtype=float), x.shape)
    a = 1 - np.exp(-2 * np.pi * fc / SR)
    y = np.zeros_like(x)
    s = 0.0
    for i in range(len(x)):
        s += a[i] * (x[i] - s)
        y[i] = s
    return y


def highpass(x, fc):
    return x - lowpass(x, fc)


def sweep(f0, f1, n, curve=1.0):
    u = (np.arange(n) / max(n - 1, 1)) ** curve
    return f0 + (f1 - f0) * u


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def cat(*parts):
    return np.concatenate(parts)


def note_f(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def tone(kind, m, dur, vol=1.0, a=0.004, curve=4.0, sustain=0.0, vib=0.0, duty=0.5):
    n = int(dur * SR)
    f = np.full(n, note_f(m) if m < 200 else m)
    if vib:
        f = f * (1 + vib * np.sin(2 * np.pi * 5.5 * np.arange(n) / SR))
    w = {'sine': sine, 'tri': tri, 'saw': saw}.get(kind)
    sig = square(f, duty) if kind == 'sq' else w(f)
    return sig * env(n, a, None, curve, sustain) * vol


def finish(x, peak=0.7, tail=0.006):
    x = np.asarray(x, dtype=float)
    m = np.max(np.abs(x)) or 1.0
    x = x / m * peak
    n = int(tail * SR)
    x[-n:] *= np.linspace(1, 0, n)
    q = np.round(x * 127).astype(np.int16)
    return np.clip(q, -127, 127).astype(np.int8)


# ----------------------------------------------------------------------------- SFX
def sfx_menu_move():
    return finish(tone('sq', 1400, 0.03, curve=5, duty=0.25), 0.45)


def sfx_menu_ok():
    return finish(cat(tone('sq', 1000, 0.04, curve=3, duty=0.25), tone('sq', 1500, 0.07, curve=4, duty=0.25)), 0.5)


def sfx_menu_back():
    return finish(cat(tone('sq', 900, 0.04, curve=3, duty=0.25), tone('sq', 600, 0.07, curve=4, duty=0.25)), 0.5)


def sfx_error():
    n = int(0.16 * SR)
    return finish(mix(square(np.full(n, 150.0), 0.5), square(np.full(n, 112.0), 0.5)) * env(n, 0.003, None, 2.0), 0.5)


def sfx_text(f):
    return finish(tone('sq', f, 0.022, curve=2.5, duty=0.25), 0.35)


def whoosh(dur, f0, f1, vol=1.0, curve=1.0, a=0.02):
    n = int(dur * SR)
    x = noise(n)
    y = lowpass(x, sweep(f0, f1, n, curve))
    e = np.sin(np.linspace(0, np.pi, n)) ** 1.5
    return y * e * vol


def sfx_slash(hi=False):
    return finish(whoosh(0.16, 700, 4200 if not hi else 5200, 1.0, 1.2), 0.65)


def sfx_hit(power=1.0):
    n = int(0.14 * SR)
    th = sine(sweep(240, 70, n, 0.6)) * env(n, 0.002, None, 5)
    nz = lowpass(noise(n), 3500) * env(n, 0.001, None, 14)
    return finish(mix(th * 0.9, nz * 0.9), 0.75)


def sfx_crit():
    n = int(0.28 * SR)
    th = sine(sweep(300, 60, n, 0.6)) * env(n, 0.002, None, 5)
    nz = lowpass(noise(n), 5000) * env(n, 0.001, None, 10)
    ting = sine(np.full(n, 1960.0)) * env(n, 0.001, None, 7) * 0.5
    return finish(mix(th, nz, ting), 0.8)


def sfx_hurt():
    n = int(0.24 * SR)
    f = sweep(430, 150, n, 0.8) * (1 + 0.04 * np.sin(2 * np.pi * 28 * np.arange(n) / SR))
    s = square(f, 0.4) * env(n, 0.002, None, 3.0)
    nz = lowpass(noise(n), 2500) * env(n, 0.001, None, 9) * 0.6
    return finish(mix(s * 0.8, nz), 0.7)


def sfx_enemy_die():
    n = int(0.34 * SR)
    nz = lowpass(noise(n), sweep(4000, 250, n, 0.7)) * env(n, 0.002, None, 3.5)
    s = sine(sweep(500, 90, n, 0.5)) * env(n, 0.002, None, 4) * 0.7
    return finish(mix(nz, s), 0.75)


def sfx_roll():
    return finish(whoosh(0.2, 300, 1800, 1.0, 1.0), 0.45)


def sfx_arrow():
    n = int(0.11 * SR)
    s = sine(sweep(1000, 520, n, 0.5)) * env(n, 0.001, None, 6)
    c = highpass(noise(n), 2000) * env(n, 0.001, None, 20) * 0.5
    return finish(mix(s, c), 0.6)


def sfx_magic():
    n = int(0.22 * SR)
    f = sweep(500, 1600, n, 0.8)
    s = sine(f) * (0.6 + 0.4 * np.sin(2 * np.pi * 30 * np.arange(n) / SR)) * env(n, 0.003, None, 3)
    s2 = sine(f * 1.5) * env(n, 0.003, None, 4) * 0.4
    return finish(mix(s, s2), 0.6)


def sfx_fire():
    n = int(0.3 * SR)
    nz = lowpass(noise(n), sweep(400, 2400, n, 1.0)) * np.sin(np.linspace(0, np.pi, n)) ** 1.2
    s = sine(sweep(120, 480, n, 1.0)) * np.sin(np.linspace(0, np.pi, n)) * 0.4
    return finish(mix(nz, s), 0.7)


def sfx_explode():
    n = int(0.55 * SR)
    nz = lowpass(noise(n), sweep(3000, 150, n, 0.5)) * env(n, 0.002, None, 3.2)
    th = sine(sweep(110, 35, n, 0.5)) * env(n, 0.002, None, 3.5)
    return finish(mix(nz * 0.9, th * 1.0), 0.85)


def sfx_coin():
    return finish(cat(tone('sq', 988, 0.055, curve=2, duty=0.5), tone('sq', 1319, 0.22, curve=5, duty=0.5)), 0.5)


def sfx_heart():
    return finish(cat(tone('sine', 660, 0.07, curve=2), tone('sine', 880, 0.07, curve=2), tone('sine', 1108, 0.2, curve=5)), 0.6)


def sfx_mana():
    n = int(0.26 * SR)
    f = sweep(700, 1800, n, 0.9)
    s = sine(f) * (0.7 + 0.3 * np.sin(2 * np.pi * 24 * np.arange(n) / SR)) * env(n, 0.004, None, 3)
    return finish(s, 0.55)


def sfx_chest():
    seq = [72, 76, 79, 84]
    parts = [tone('sq', m, 0.08, curve=2, duty=0.25) for m in seq]
    tail = tone('tri', 88, 0.35, curve=4) * 0.8 + tone('sine', 91, 0.35, curve=4, vib=0.01) * 0.4
    return finish(cat(*parts, tail), 0.6)


def sfx_item():
    parts = [tone('sq', m, 0.07, curve=2, duty=0.25) for m in (79, 83, 86)]
    tail = tone('tri', 91, 0.3, curve=3)
    return finish(cat(*parts, tail), 0.6)


def sfx_levelup():
    seq = [72, 76, 79, 84, 88, 91]
    parts = [tone('sq', m, 0.085, curve=1.6, duty=0.25) * 0.8 + tone('tri', m - 12, 0.085, curve=1.6) * 0.6 for m in seq]
    n = int(0.75 * SR)
    chord = sum(tone('sq', m, 0.75, curve=2.4, vib=0.008, duty=0.25) * 0.5 + tone('tri', m - 12, 0.75, curve=2.4) * 0.5 for m in (79, 84, 88, 91))
    return finish(cat(*parts, chord), 0.7)


def sfx_potion():
    g = [tone('sine', f, 0.06, curve=2) for f in (210, 260, 320)]
    n = int(0.3 * SR)
    sp = sine(sweep(900, 1900, n, 0.7)) * (0.6 + 0.4 * np.sin(2 * np.pi * 20 * np.arange(n) / SR)) * env(n, 0.01, None, 3) * 0.5
    return finish(cat(*g, sp), 0.6)


def sfx_door():
    n = int(0.3 * SR)
    c = mix(sine(np.full(n, 310.0)), sine(np.full(n, 470.0)) * 0.7) * env(n, 0.001, None, 6)
    nz = lowpass(noise(n), 2500) * env(n, 0.001, None, 14)
    s = whoosh(0.3, 200, 900, 0.5)
    return finish(cat(mix(c, nz * 0.8), s), 0.7)


def sfx_warp():
    n = int(0.45 * SR)
    nz = lowpass(noise(n), sweep(300, 5000, n, 1.5)) * np.sin(np.linspace(0, np.pi, n)) ** 1.5
    s = sine(sweep(250, 1400, n, 1.2)) * np.sin(np.linspace(0, np.pi, n)) * 0.5
    return finish(mix(nz, s), 0.55)


def sfx_boss_roar():
    n = int(0.8 * SR)
    f = sweep(95, 60, n, 0.6) * (1 + 0.08 * np.sin(2 * np.pi * 9 * np.arange(n) / SR))
    s = lowpass(saw(f), 700) * env(n, 0.04, None, 1.6)
    nz = lowpass(noise(n), 900) * env(n, 0.05, None, 2.0) * 0.6
    return finish(mix(s, nz), 0.8)


def sfx_boss_die():
    parts = []
    for i in range(3):
        n = int(0.4 * SR)
        parts.append(lowpass(noise(n), sweep(3500, 150, n, 0.6)) * env(n, 0.002, None, 3) + sine(sweep(120, 35, n, 0.5)) * env(n, 0.002, None, 3))
    n = int(0.7 * SR)
    parts.append(lowpass(noise(n), sweep(2500, 100, n, 0.5)) * env(n, 0.01, None, 2.5))
    return finish(cat(*parts), 0.85)


def sfx_bush():
    n = int(0.13 * SR)
    return finish(highpass(noise(n), 1800) * env(n, 0.002, None, 9), 0.5)


def sfx_spin():
    n = int(0.32 * SR)
    nz = lowpass(noise(n), sweep(600, 3600, n, 0.6)) * (0.6 + 0.4 * np.sin(2 * np.pi * 14 * np.arange(n) / SR)) * np.sin(np.linspace(0, np.pi, n)) ** 0.8
    return finish(nz, 0.65)


def sfx_dash():
    n = int(0.22 * SR)
    nz = lowpass(noise(n), sweep(5000, 600, n, 0.6)) * env(n, 0.004, None, 3)
    s = sine(sweep(900, 200, n, 0.5)) * env(n, 0.004, None, 4) * 0.4
    return finish(mix(nz, s), 0.6)


def sfx_alert():
    return finish(cat(tone('sq', 880, 0.04, curve=2, duty=0.25), tone('sq', 1320, 0.09, curve=4, duty=0.25)), 0.45)


def melody(notes, vol=1.0, kind='sq', duty=0.25, tail_ring=0.0):
    parts = []
    for (m, d) in notes:
        if m is None:
            parts.append(np.zeros(int(d * SR)))
        else:
            parts.append(tone(kind, m, d, vol, curve=2.2, duty=duty) * 0.7 + tone('tri', m - 12, d, vol, curve=2.2) * 0.6)
    return cat(*parts)


def sfx_victory():
    q = 0.13
    notes = [(72, q), (72, q), (72, q), (72, q * 2.5), (68, q * 2.5), (70, q * 2.5), (72, q * 1.5), (70, q * .5), (72, q * 4)]
    notes += [(None, 0.05), (76, q), (79, q), (84, q * 4)]
    return finish(melody(notes), 0.7)


def sfx_gameover():
    q = 0.28
    notes = [(67, q), (66, q), (65, q), (64, q * 2), (None, q * 0.5), (62, q), (60, q * 4)]
    return finish(melody(notes, kind='tri', duty=0.5) * 0.9, 0.65)


def sfx_equip():
    n = int(0.05 * SR)
    c = highpass(noise(n), 1500) * env(n, 0.001, None, 14)
    return finish(cat(c, tone('sq', 700, 0.05, curve=3, duty=0.5)), 0.5)


def sfx_save():
    return finish(cat(tone('tri', 72, 0.1, curve=2), tone('tri', 76, 0.1, curve=2), tone('tri', 79, 0.3, curve=3)), 0.6)


def sfx_bat():
    n = int(0.05 * SR)
    return finish(highpass(noise(n), 800) * env(n, 0.002, None, 10), 0.3)


def sfx_wolf():
    n = int(0.3 * SR)
    f = sweep(150, 95, n, 0.7) * (1 + 0.05 * np.sin(2 * np.pi * 14 * np.arange(n) / SR))
    s = lowpass(saw(f), 900) * np.sin(np.linspace(0, np.pi, n)) ** 0.7
    return finish(s, 0.6)


def sfx_slime():
    n = int(0.1 * SR)
    f = sweep(180, 420, n, 0.8) * (1 + 0.1 * np.sin(2 * np.pi * 40 * np.arange(n) / SR))
    return finish(sine(f) * env(n, 0.003, None, 4), 0.55)


# ----------------------------------------------------------------------------- combat SFX (swings, impacts, finishers)
def whoosh2(dur, f0, f1, peak=0.35, vol=1.0, curve=1.0):
    """asymmetric swish: fast attack, longer tail (reads as a weapon swing)."""
    n = int(dur * SR)
    y = lowpass(noise(n), sweep(f0, f1, n, curve))
    t = np.arange(n) / max(n - 1, 1)
    e = np.where(t < peak, (t / peak) ** 1.3, ((1 - t) / (1 - peak)) ** 1.8)
    return y * e * vol


def sfx_swing1():
    return finish(whoosh2(0.12, 800, 5200, 0.32), 0.62)


def sfx_swing2():
    n = int(0.14 * SR)
    th = sine(sweep(150, 90, n, 0.6)) * env(n, 0.002, None, 9) * 0.35
    return finish(mix(whoosh2(0.14, 500, 4200, 0.38), th), 0.66)


def sfx_thrust():
    n = int(0.1 * SR)
    sw = sine(sweep(1400, 2800, n, 0.7)) * env(n, 0.002, None, 6) * 0.25
    return finish(mix(whoosh2(0.1, 1200, 6200, 0.25), sw), 0.6)


def sfx_smash():
    n = int(0.22 * SR)
    rum = sine(sweep(140, 55, n, 0.6)) * env(n, 0.01, None, 3.5) * 0.55
    return finish(mix(whoosh2(0.22, 220, 2600, 0.5), rum), 0.72)


def sfx_stab():
    n = int(0.07 * SR)
    nz = highpass(noise(n), 2200) * env(n, 0.001, None, 10)
    s = square(sweep(2600, 1500, n, 0.5), 0.25) * env(n, 0.001, None, 12) * 0.45
    return finish(mix(nz * 0.8, s), 0.55)


def sfx_flurry():
    parts = []
    for i in range(3):
        n = int(0.05 * SR)
        nz = highpass(noise(n), 2000) * env(n, 0.001, None, 12)
        s = square(sweep(2200 + i * 350, 1400 + i * 250, n, 0.5), 0.25) * env(n, 0.001, None, 14) * 0.45
        parts.append(mix(nz * 0.8, s))
        parts.append(np.zeros(int(0.02 * SR)))
    return finish(cat(*parts), 0.6)


def sfx_bow():
    n = int(0.15 * SR)
    pl = sine(sweep(720, 260, n, 0.4)) * env(n, 0.001, None, 7)
    hm = tri(sweep(1440, 520, n, 0.4)) * env(n, 0.001, None, 10) * 0.35
    ck = highpass(noise(n), 2500) * env(n, 0.0005, None, 45) * 0.5
    wh = sine(sweep(2300, 1200, n, 0.6)) * env(n, 0.01, None, 4) * 0.12
    return finish(mix(pl, hm, ck, wh), 0.6)


def sfx_bow2():
    n = int(0.2 * SR)
    pl = sine(sweep(520, 150, n, 0.4)) * env(n, 0.001, None, 6)
    hm = tri(sweep(1040, 300, n, 0.4)) * env(n, 0.001, None, 8) * 0.4
    ck = highpass(noise(n), 2200) * env(n, 0.0005, None, 40) * 0.6
    return finish(mix(pl, hm, ck, whoosh2(0.2, 600, 3600, 0.3) * 0.5), 0.68)


def sfx_zap():
    n = int(0.14 * SR)
    f = sweep(520, 1500, n, 0.7) * (1 + 0.03 * np.sin(2 * np.pi * 30 * np.arange(n) / SR))
    s = square(f, 0.25) * env(n, 0.002, None, 5) * 0.5 + sine(f * 2) * env(n, 0.002, None, 6) * 0.25
    return finish(s, 0.55)


def sfx_zap2():
    n = int(0.24 * SR)
    f = sweep(300, 1800, n, 0.8)
    s = square(f, 0.25) * env(n, 0.003, None, 3.5) * 0.45 + sine(f * 1.5) * env(n, 0.003, None, 4) * 0.35
    gate = (np.sin(2 * np.pi * 45 * np.arange(n) / SR) > -0.3).astype(float)
    cr = highpass(noise(n), 1800) * gate * env(n, 0.003, None, 5) * 0.35
    return finish(mix(s, cr), 0.65)


def sfx_hit_slash():
    n = int(0.11 * SR)
    nz = highpass(lowpass(noise(n), 5000), 700) * env(n, 0.001, None, 12)
    th = sine(sweep(210, 80, n, 0.6)) * env(n, 0.001, None, 8) * 0.7
    return finish(mix(nz * 0.9, th), 0.8)


def sfx_hit_stab():
    n = int(0.08 * SR)
    nz = highpass(noise(n), 1800) * env(n, 0.001, None, 14) * 0.6
    bl = square(sweep(1700, 600, n, 0.6), 0.25) * env(n, 0.001, None, 9) * 0.5
    th = sine(sweep(260, 110, n, 0.6)) * env(n, 0.001, None, 9) * 0.55
    return finish(mix(nz, bl, th), 0.75)


def sfx_hit_heavy():
    n = int(0.28 * SR)
    th = sine(sweep(170, 42, n, 0.55)) * env(n, 0.002, None, 4.5)
    nz = lowpass(noise(n), sweep(4500, 180, n, 0.45)) * env(n, 0.001, None, 6) * 0.9
    cr = highpass(noise(n), 2500) * env(n, 0.0005, None, 40) * 0.7
    return finish(mix(th, nz, cr), 0.88)


def sfx_hit_arrow():
    n = int(0.09 * SR)
    th = sine(sweep(380, 140, n, 0.5)) * env(n, 0.001, None, 9)
    wd = tri(np.full(n, 520.0)) * env(n, 0.001, None, 25) * 0.5
    tk = highpass(noise(n), 3000) * env(n, 0.0005, None, 40) * 0.5
    return finish(mix(th, wd, tk), 0.75)


def sfx_hit_magic():
    n = int(0.15 * SR)
    gate = (np.sin(2 * np.pi * 55 * np.arange(n) / SR) > -0.2).astype(float)
    nz = highpass(noise(n), 1500) * gate * env(n, 0.001, None, 6)
    s = sine(sweep(2000, 500, n, 0.7)) * env(n, 0.001, None, 5) * 0.6
    return finish(mix(nz * 0.7, s), 0.72)


def sfx_hit_bone():
    n = int(0.17 * SR)
    out = np.zeros(n)
    for (d, f, a) in ((0.0, 1100, 1.0), (0.03, 1650, 0.8), (0.062, 900, 0.7), (0.09, 1400, 0.45)):
        i0 = int(d * SR)
        m = n - i0
        out[i0:] += sine(np.full(m, float(f))) * env(m, 0.0005, None, 22) * a
    out += highpass(noise(n), 2500) * env(n, 0.0005, None, 30) * 0.4
    return finish(out, 0.7)


def sfx_hit_slime():
    n = int(0.14 * SR)
    f = sweep(340, 110, n, 0.7) * (1 + 0.12 * np.sin(2 * np.pi * 38 * np.arange(n) / SR))
    s = sine(f) * env(n, 0.002, None, 5)
    nz = lowpass(noise(n), 1200) * env(n, 0.001, None, 8) * 0.6
    return finish(mix(s, nz), 0.7)


def sfx_hit_armor():
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    cl = (np.sin(2 * np.pi * 880 * t) + 0.6 * np.sin(2 * np.pi * 1330 * t) + 0.3 * np.sin(2 * np.pi * 2110 * t)) * env(n, 0.0005, None, 7)
    nz = highpass(noise(n), 2000) * env(n, 0.0005, None, 30) * 0.6
    th = sine(sweep(160, 70, n, 0.6)) * env(n, 0.001, None, 8) * 0.6
    return finish(mix(cl * 0.6, nz, th), 0.75)


def sfx_finish():
    parts = [tone('sq', 79, 0.05, curve=2, duty=0.25), tone('sq', 86, 0.05, curve=2, duty=0.25), tone('sq', 91, 0.14, curve=3.5, duty=0.25)]
    mel = cat(*parts)
    n = len(mel)
    nz = lowpass(noise(n), sweep(5000, 600, n, 0.5)) * env(n, 0.002, None, 4) * 0.5
    th = sine(sweep(120, 50, n, 0.5)) * env(n, 0.002, None, 5) * 0.6
    return finish(mix(mel * 0.8, nz, th), 0.8)


SFX = [
    ('MENU_MOVE', sfx_menu_move), ('MENU_OK', sfx_menu_ok), ('MENU_BACK', sfx_menu_back), ('ERROR', sfx_error),
    ('TEXT', lambda: sfx_text(520)), ('TEXT2', lambda: sfx_text(690)), ('TEXT3', lambda: sfx_text(400)),
    ('SLASH', lambda: sfx_slash(False)), ('SLASH2', lambda: sfx_slash(True)),
    ('HIT', sfx_hit), ('CRIT', sfx_crit), ('HURT', sfx_hurt), ('ENEMY_DIE', sfx_enemy_die), ('ROLL', sfx_roll),
    ('ARROW', sfx_arrow), ('MAGIC', sfx_magic), ('FIRE', sfx_fire), ('EXPLODE', sfx_explode),
    ('COIN', sfx_coin), ('HEART', sfx_heart), ('MANA', sfx_mana), ('CHEST', sfx_chest), ('ITEM', sfx_item),
    ('LEVELUP', sfx_levelup), ('POTION', sfx_potion), ('DOOR', sfx_door), ('WARP', sfx_warp),
    ('BOSS_ROAR', sfx_boss_roar), ('BOSS_DIE', sfx_boss_die), ('BUSH', sfx_bush), ('SPIN', sfx_spin),
    ('DASH', sfx_dash), ('ALERT', sfx_alert), ('VICTORY', sfx_victory), ('GAMEOVER', sfx_gameover),
    ('EQUIP', sfx_equip), ('SAVE', sfx_save), ('BAT', sfx_bat), ('WOLF', sfx_wolf), ('SLIME', sfx_slime),
    ('SWING1', sfx_swing1), ('SWING2', sfx_swing2), ('THRUST', sfx_thrust), ('SMASH', sfx_smash), ('STAB', sfx_stab),
    ('FLURRY', sfx_flurry), ('BOW', sfx_bow), ('BOW2', sfx_bow2), ('ZAP', sfx_zap), ('ZAP2', sfx_zap2),
    ('HIT_SLASH', sfx_hit_slash), ('HIT_STAB', sfx_hit_stab), ('HIT_HEAVY', sfx_hit_heavy), ('HIT_ARROW', sfx_hit_arrow),
    ('HIT_MAGIC', sfx_hit_magic), ('HIT_BONE', sfx_hit_bone), ('HIT_SLIME', sfx_hit_slime), ('HIT_ARMOR', sfx_hit_armor),
    ('FINISH', sfx_finish),
]

# ----------------------------------------------------------------------------- MUSIC
NOTE = {'c': 0, 'd': 2, 'e': 4, 'f': 5, 'g': 7, 'a': 9, 'b': 11}


def midi(name):
    n = name[0]
    s = NOTE[n]
    i = 1
    while i < len(name) and name[i] in '#b':
        s += 1 if name[i] == '#' else -1
        i += 1
    o = int(name[i:])
    return 12 * (o + 1) + s


def parse(s):
    out = []
    for tok in s.split():
        if tok.startswith('@'):
            out.append(('inst', int(tok[1:])))
            continue
        nm, d = tok.split(':')
        out.append((0 if nm == 'r' else midi(nm), int(d)))
    return out


class Song:
    def __init__(self, name, spd, bars=16):
        self.name, self.spd, self.bars = name, spd, bars
        self.tr = [[], [], [], []]

    def add(self, ch, events, expect=None):
        self.tr[ch] += events if isinstance(events, list) else parse(events)

    def total(self, ch):
        return sum(e[1] for e in self.tr[ch] if e[0] != 'inst')

    def encode(self, loop=True):
        out = []
        for ch in range(4):
            b = [0xFD]
            for e in self.tr[ch]:
                if e[0] == 'inst':
                    b.append(0xE0 | e[1])
                else:
                    assert 0 <= e[0] < 128 and 1 <= e[1] <= 255, (self.name, ch, e)
                    b += [e[0], e[1]]
            b.append(0xFE if loop else 0xFF)
            out.append(b)
        return out


TRIAD = {'M': (0, 4, 7), 'm': (0, 3, 7), '7': (0, 4, 7), 'd': (0, 3, 6)}


def chord_notes(root, q, octave=4):
    r = midi(root + str(octave))
    return [r + i for i in TRIAD[q]]


def bass_bar(style, root, q, oct_=2):
    r = midi(root + str(oct_))
    f = r + 7
    o = r + 12
    if style == 'march':
        return [(r, 4), (f, 4), (r, 4), (f, 4)]
    if style == 'oompah':
        return [(r, 2), (0, 2), (f, 2), (0, 2)] * 2
    if style == 'drive':
        return [(r, 2), (r, 2), (o, 2), (r, 2), (r, 2), (r, 2), (o, 2), (f, 2)]
    if style == 'drone':
        return [(r, 8), (f, 8)]
    if style == 'slow':
        return [(r, 6), (0, 2), (f, 4), (0, 4)]
    third = r + (4 if q in ('M', '7') else 3)
    if style == 'walk':                                    # root - third - fifth - third
        return [(r, 4), (third, 4), (f, 4), (third, 4)]
    if style == 'pump':                                    # eighth-note octave pump
        return [(r, 2), (o, 2)] * 4
    if style == 'syncop':
        return [(r, 3), (0, 1), (r, 2), (0, 2), (f, 3), (0, 1), (o, 2), (f, 2)]
    if style == 'pedal':
        return [(r, 6), (r, 2), (r, 4), (f, 4)]
    if style == 'climb':                                   # rising run into the next bar
        return [(r, 4), (r, 2), (third, 2), (f, 4), (o, 2), (f, 2)]
    raise ValueError(style)


def arp_bar(style, root, q, oct_=4):
    n = chord_notes(root, q, oct_)
    a, b, c = n
    if style == 'harp8':
        return [(x, 2) for x in (a, b, c, b, a, b, c, b)]
    if style == 'harp8up':
        return [(x, 2) for x in (a, b, c, a + 12, c, b, a, b)]
    if style == 'offbeat':
        return [(0, 2), (b, 2), (0, 2), (c, 2)] * 2
    if style == 'stab16':
        return [(x, 1) for x in (a, c, a + 12, c)] * 4
    if style == 'slowarp':
        return [(a, 4), (b, 4), (c, 4), (b, 4)]
    if style == 'arp16':
        return [(x, 1) for x in (a, b, c, a + 12, c, b, a, b)] * 2
    if style == 'wave':
        return [(x, 2) for x in (a, c, b, a + 12, c, b, a, b)]
    if style == 'sus':
        return [(c, 8), (b, 8)]
    if style == 'dyad':
        return [(b, 6), (0, 2), (c, 6), (0, 2)]
    if style == 'rest':
        return [(0, 16)]
    raise ValueError(style)


def perc_bar(pattern):
    """pattern: dict step -> drum id ; returns events covering 16 steps"""
    ev = []
    t = 0
    steps = sorted(pattern)
    for s in steps:
        if s > t:
            ev.append((0, s - t))
            t = s
        nxt = [x for x in steps if x > s]
        d = (nxt[0] if nxt else 16) - s
        ev.append((pattern[s], d))
        t = s + d
    if t < 16:
        ev.append((0, 16 - t))
    return ev


def make_song(name, spd, chords, melody_str, bass_style, arp_style, drums, insts, bars_expected=16):
    return make_song2(name, spd, insts, [dict(chords=chords, mel=melody_str, bass=bass_style, arp=arp_style, drums=drums)])


def bars(txt):
    """one bar per line; every bar must add up to 16 ticks"""
    out = []
    for i, line in enumerate([l for l in txt.strip().split('\n') if l.strip()]):
        ev = parse(line)
        tot = sum(e[1] for e in ev if e[0] != 'inst')
        assert tot == 16, ('bar %d has %d ticks: %s' % (i + 1, tot, line))
        out += ev
    return out


def make_song2(name, spd, insts, sections):
    """sections: dicts of chords [(root, quality)], mel (parse string or event list), bass, arp (style or list of styles),
    drums (list of patterns, cycled per bar), optional fill (tom/snare roll on every 4th bar), crash (crash on bar 1),
    inst (3-tuple to switch instruments at the start of the section)."""
    s = Song(name, spd)
    s.add(0, [('inst', insts[0])])
    s.add(1, [('inst', insts[1])])
    s.add(2, [('inst', insts[2])])
    s.add(3, [('inst', 0)])
    FILL = {0: K, 4: S, 8: K, 12: T, 13: T, 14: S, 15: S}
    for sec in sections:
        if sec.get('inst'):
            for ch in range(3):
                s.add(ch, [('inst', sec['inst'][ch])])
        mel = sec['mel'] if isinstance(sec['mel'], list) else parse(sec['mel'])
        s.add(0, mel)
        arps = sec['arp'] if isinstance(sec['arp'], list) else [sec['arp']]
        basses = sec['bass'] if isinstance(sec['bass'], list) else [sec['bass']]
        for i, (root, q) in enumerate(sec['chords']):
            s.add(1, arp_bar(arps[i % len(arps)], root, q, 4))
            s.add(2, bass_bar(basses[i % len(basses)], root, q, 2))
            if sec.get('drums'):
                pat = sec['drums'][i % len(sec['drums'])]
                if sec.get('crash') and i == 0:
                    pat = dict(pat)
                    pat[0] = C
                if sec.get('fill') and i % 4 == 3:
                    pat = FILL
                s.add(3, perc_bar(pat))
            else:
                s.add(3, [(0, 16)])
    for ch in range(4):
        tot = s.total(ch)
        want = s.total(1)
        assert tot == want, (name, ch, tot, want)
    return s


K, S, Hh, O, T, C = 1, 2, 3, 4, 5, 6

# ============================================================== TITLE (D minor, heroic)
TITLE_CH = [('d', 'm'), ('bb', 'M'), ('f', 'M'), ('c', 'M'), ('d', 'm'), ('bb', 'M'), ('g', 'm'), ('a', 'M')] * 2
TITLE_MEL = """
d5:6 e5:2 f5:4 a5:4  g5:6 f5:2 d5:8  c5:6 d5:2 f5:4 a5:4  g5:12 e5:4
d5:6 e5:2 f5:4 a5:4  bb5:6 a5:2 g5:8  g5:4 a5:4 bb5:4 d6:4  a5:12 e5:4
f5:4 a5:4 d6:8  d6:6 c6:2 bb5:4 g5:4  a5:6 g5:2 f5:4 c5:4  e5:4 g5:4 c6:8
d6:4 c6:4 a5:4 f5:4  g5:4 bb5:4 d6:8  g5:8 a5:4 c#6:4  e6:8 d6:4 c#6:4
"""
TITLE_BRIDGE_CH = [('bb', 'M'), ('f', 'M'), ('c', 'M'), ('d', 'm'), ('bb', 'M'), ('g', 'm'), ('a', 'M'), ('a', 'M')]
TITLE_BRIDGE = bars("""
bb5:4 d6:4 f6:8
a5:4 c6:4 f6:8
g5:4 c6:4 e6:8
f6:6 e6:2 d6:8
d6:4 f6:4 bb6:8
g6:6 f6:2 d6:4 bb5:4
a5:4 c#6:4 e6:4 a6:4
a6:12 r:4
""")
TITLE_DR = [{0: K, 8: K}, {0: K, 8: K, 12: Hh}, {0: K, 4: Hh, 8: K, 12: Hh}, {0: K, 8: K, 12: S}]

# ============================================================== VILLAGE (G major, folk)
V_A_CH = [('g', 'M'), ('c', 'M'), ('g', 'M'), ('d', 'M'), ('g', 'M'), ('c', 'M'), ('d', 'M'), ('g', 'M')]
V_A = bars("""
d6:4 b5:2 g5:2 b5:4 d6:4
e6:4 c6:2 g5:2 c6:8
b5:4 g5:2 b5:2 d6:4 b5:4
a5:6 f#5:2 a5:4 r:4
d6:4 b5:2 g5:2 b5:4 d6:4
e6:4 g6:4 e6:4 c6:4
d6:6 c6:2 b5:2 a5:2 f#5:4
g5:12 r:4
""")
V_B_CH = [('e', 'm'), ('c', 'M'), ('g', 'M'), ('d', 'M'), ('e', 'm'), ('c', 'M'), ('d', 'M'), ('g', 'M')]
V_B = bars("""
b5:4 e6:4 g6:4 e6:4
c6:4 e6:4 g6:8
g6:4 d6:2 g6:2 b6:4 g6:4
f#6:4 a6:4 f#6:4 d6:4
e6:6 d6:2 b5:4 g5:4
c6:4 g5:2 c6:2 e6:8
d6:4 f#6:4 a6:4 f#6:4
g6:8 d6:4 b5:4
""")
# second pass of A: the tune is ornamented with 16th-note turns
V_A2 = bars("""
d6:3 e6:1 d6:2 b5:2 g5:2 b5:2 d6:4
e6:3 f6:1 e6:2 c6:2 g5:2 c6:2 e6:4
b5:3 c6:1 b5:2 g5:2 b5:2 d6:2 b5:4
a5:4 c6:2 a5:2 f#5:4 a5:2 r:2
d6:3 e6:1 d6:2 b5:2 g5:2 b5:2 d6:4
e6:4 g6:2 e6:2 g6:4 e6:2 c6:2
d6:4 f#6:2 d6:2 c6:2 b5:2 a5:2 f#5:2
g5:8 b5:4 d6:4
""")
VILLAGE_DR = [{0: K, 4: S, 8: K, 12: S, 2: Hh, 6: Hh, 10: Hh, 14: Hh}, {0: K, 4: S, 8: K, 12: S, 2: Hh, 6: Hh, 10: Hh, 14: O}]

# ============================================================== FOREST (E minor, mysterious)
F_A_CH = [('e', 'm'), ('c', 'M'), ('g', 'M'), ('d', 'M'), ('e', 'm'), ('c', 'M'), ('a', 'm'), ('b', 'M')]
F_A = bars("""
e5:6 g5:2 b5:8
c6:6 b5:2 g5:8
g5:4 b5:4 d6:4 b5:4
a5:6 f#5:2 d5:8
g5:4 e5:4 b5:4 g5:4
e6:6 d6:2 c6:4 g5:4
a5:4 c6:4 e6:4 c6:4
d#6:6 b5:2 f#5:8
""")
F_B_CH = [('e', 'm'), ('g', 'M'), ('a', 'm'), ('e', 'm'), ('c', 'M'), ('g', 'M'), ('d', 'M'), ('e', 'm')]
F_B = bars("""
b5:8 e6:8
d6:6 b5:2 g5:4 b5:4
c6:6 e6:2 a6:8
g6:6 e6:2 b5:8
c6:4 e6:4 g6:4 e6:4
b5:4 d6:4 g6:8
f#6:4 e6:4 d6:4 a5:4
e6:12 r:4
""")
FOREST_DR = [{0: K}, {0: K, 12: Hh}, {0: K, 8: Hh}, {0: K, 4: Hh, 12: Hh}]

# ============================================================== CRYPT (C minor, eerie)
C_A_CH = [('c', 'm'), ('c', 'm'), ('ab', 'M'), ('bb', 'M'), ('c', 'm'), ('f', 'm'), ('g', 'M'), ('g', 'M')]
C_A = bars("""
g5:6 r:2 eb5:4 g5:4
f5:4 eb5:4 d5:8
eb6:6 c6:2 ab5:8
d6:4 bb5:4 f5:8
g5:6 g5:2 c6:4 eb6:4
f6:6 eb6:2 c6:8
b5:4 d6:4 g5:8
ab5:6 g5:2 r:8
""")
C_B_CH = [('c', 'm'), ('ab', 'M'), ('eb', 'M'), ('bb', 'M'), ('f', 'm'), ('c', 'm'), ('g', 'M'), ('c', 'm')]
C_B = bars("""
c6:8 eb6:4 g6:4
ab6:6 g6:2 eb6:8
eb6:4 g6:4 bb5:4 eb6:4
d6:6 f6:2 bb5:8
ab5:4 c6:4 f6:4 c6:4
g5:6 eb5:2 c5:8
b5:8 d6:4 f6:4
c6:12 r:4
""")
CRYPT_DR = [{0: K}, {0: K, 8: T}, {0: K}, {0: K, 8: T, 14: Hh}]

# ============================================================== BOSS (D minor, relentless)
BOSS_CH = [('d', 'm'), ('d', 'm'), ('bb', 'M'), ('c', 'M'), ('d', 'm'), ('d', 'm'), ('g', 'm'), ('a', 'M'),
           ('d', 'm'), ('d', 'm'), ('f', 'M'), ('c', 'M'), ('bb', 'M'), ('a', 'M'), ('g', 'm'), ('a', 'M')]
BOSS_MEL = """
d5:2 d5:2 f5:2 d5:2 a5:4 g5:2 f5:2  e5:2 e5:2 g5:2 e5:2 bb5:4 a5:2 g5:2  d6:4 c6:2 bb5:2 a5:4 bb5:2 c6:2  c6:4 b5:2 c6:2 e6:4 g6:4
d6:2 d6:2 f6:2 d6:2 a6:4 g6:2 f6:2  e6:2 f6:2 g6:2 e6:2 d6:8  bb5:2 d6:2 g6:4 f6:2 d6:2 bb5:4  a5:2 c#6:2 e6:4 a6:4 g6:2 e6:2
a5:4 d6:4 f6:4 a6:4  g6:2 f6:2 e6:2 d6:2 c6:4 a5:4  a5:2 c6:2 f6:4 e6:2 c6:2 a5:4  g5:2 c6:2 e6:4 d6:2 c6:2 g5:4
d6:2 f6:2 bb6:4 a6:2 f6:2 d6:4  e6:2 a6:2 g6:4 e6:2 c#6:2 e6:4  g6:4 f6:2 d6:2 bb5:4 d6:4  a5:2 c#6:2 e6:2 a6:2 e6:2 c#6:2 a5:4
"""
BOSS_BR_CH = [('bb', 'M'), ('c', 'M'), ('d', 'm'), ('f', 'M'), ('g', 'm'), ('a', 'M'), ('bb', 'M'), ('a', 'M')]
BOSS_BR = bars("""
bb5:4 d6:4 f6:8
c6:4 e6:4 g6:8
d6:2 f6:2 a6:4 f6:4 d6:4
f6:4 a6:4 a6:4 g6:2 f6:2
g6:4 bb6:4 g6:4 d6:4
a5:2 c#6:2 e6:4 a6:8
bb5:4 d6:4 f6:4 d6:4
e6:4 c#6:4 a5:4 e5:4
""")
BOSS_DR = [{0: K, 4: S, 8: K, 10: K, 12: S, 2: Hh, 6: Hh, 14: Hh}, {0: K, 4: S, 8: K, 12: S, 14: S, 2: Hh, 6: Hh, 10: Hh}]

# ============================================================== EMBER (E phrygian, forge-fire)
E_A_CH = [('e', 'm'), ('f', 'M'), ('e', 'm'), ('f', 'M'), ('d', 'm'), ('e', 'm'), ('f', 'M'), ('e', 'm')]
E_A = bars("""
e5:6 f5:2 e5:4 b4:4
a5:6 g5:2 f5:8
e5:4 g5:4 b5:4 g5:4
f5:4 a5:4 c6:8
d6:6 c6:2 a5:4 f5:4
e6:4 d6:4 b5:4 g5:4
c6:4 a5:4 f5:4 a5:4
b5:12 r:4
""")
E_B_CH = [('a', 'm'), ('g', 'M'), ('f', 'M'), ('e', 'M'), ('a', 'm'), ('d', 'm'), ('f', 'M'), ('e', 'M')]
E_B = bars("""
a5:4 c6:4 e6:8
g5:4 b5:4 d6:8
f5:4 a5:4 c6:8
e5:4 g#5:4 b5:4 e6:4
a5:4 e6:4 c6:4 a5:4
d6:4 f6:4 a6:8
c6:4 f6:4 e6:4 c6:4
b5:6 g#5:2 e5:8
""")
EMBER_DR = [{0: K, 6: T, 8: K, 12: T, 14: T}, {0: K, 4: T, 8: K, 10: K, 12: S}, {0: K, 3: T, 8: K, 12: S, 14: T}, {0: K, 4: S, 8: K, 12: S, 2: Hh, 6: Hh, 10: Hh, 14: Hh}]


def build_songs():
    songs = []
    # title: theme, bridge, theme again with brass over a driving bass
    songs.append(make_song2('title', 9, (4, 3, 0), [
        dict(chords=TITLE_CH[:8], mel=parse(TITLE_MEL.strip().split('\n')[0] + ' ' + TITLE_MEL.strip().split('\n')[1]), bass='march', arp='slowarp', drums=TITLE_DR),
        dict(chords=TITLE_CH[8:], mel=parse(TITLE_MEL.strip().split('\n')[2] + ' ' + TITLE_MEL.strip().split('\n')[3]), bass=['march', 'walk'], arp=['slowarp', 'wave'], drums=TITLE_DR, fill=True),
        dict(chords=TITLE_BRIDGE_CH, mel=TITLE_BRIDGE, bass='pump', arp='arp16', drums=TITLE_DR, crash=True, fill=True, inst=(0, 1, 0)),
        dict(chords=TITLE_CH[:8], mel=parse(TITLE_MEL.strip().split('\n')[0] + ' ' + TITLE_MEL.strip().split('\n')[1]), bass='walk', arp='wave', drums=TITLE_DR, crash=True, inst=(4, 3, 0)),
    ]))
    songs.append(make_song2('village', 7, (0, 1, 0), [
        dict(chords=V_A_CH, mel=V_A, bass='oompah', arp='offbeat', drums=VILLAGE_DR[:1]),
        dict(chords=V_B_CH, mel=V_B, bass=['walk', 'oompah'], arp='harp8', drums=VILLAGE_DR, fill=True, inst=(0, 3, 0)),
        dict(chords=V_A_CH, mel=V_A2, bass='syncop', arp='wave', drums=VILLAGE_DR, crash=True, inst=(4, 1, 0)),
        dict(chords=V_B_CH, mel=V_B, bass=['walk', 'pump'], arp='harp8up', drums=VILLAGE_DR, fill=True, crash=True, inst=(0, 3, 0)),
    ]))
    songs.append(make_song2('forest', 10, (2, 3, 1), [
        dict(chords=F_A_CH, mel=F_A, bass='slow', arp='harp8', drums=FOREST_DR),
        dict(chords=F_B_CH, mel=F_B, bass=['walk', 'slow'], arp='wave', drums=FOREST_DR, fill=True, inst=(0, 3, 1)),
        dict(chords=F_A_CH, mel=F_A, bass='climb', arp='harp8up', drums=FOREST_DR, crash=True, inst=(2, 1, 1)),
        dict(chords=F_B_CH, mel=F_B, bass='walk', arp='arp16', drums=FOREST_DR, fill=True, inst=(4, 3, 1)),
    ]))
    songs.append(make_song2('crypt', 11, (2, 5, 0), [
        dict(chords=C_A_CH, mel=C_A, bass='drone', arp='sus', drums=CRYPT_DR),
        dict(chords=C_B_CH, mel=C_B, bass=['drone', 'pedal'], arp=['dyad', 'slowarp'], drums=CRYPT_DR, fill=True, inst=(2, 3, 0)),
        dict(chords=C_A_CH, mel=C_A, bass='pedal', arp='slowarp', drums=CRYPT_DR, crash=True, inst=(5, 5, 0)),
        dict(chords=C_B_CH, mel=C_B, bass='drone', arp='dyad', drums=CRYPT_DR, fill=True, inst=(2, 5, 0)),
    ]))
    songs.append(make_song2('boss', 5, (4, 1, 0), [
        dict(chords=BOSS_CH, mel=BOSS_MEL, bass=['drive', 'drive', 'syncop', 'drive'], arp='stab16', drums=BOSS_DR, fill=True),
        dict(chords=BOSS_BR_CH, mel=BOSS_BR, bass='pump', arp='arp16', drums=BOSS_DR, crash=True, fill=True, inst=(0, 3, 0)),
        dict(chords=BOSS_CH, mel=BOSS_MEL, bass=['drive', 'pump'], arp='stab16', drums=BOSS_DR, crash=True, fill=True, inst=(4, 1, 0)),
    ]))
    songs.append(make_song2('ember', 8, (4, 1, 0), [
        dict(chords=E_A_CH, mel=E_A, bass='pedal', arp='dyad', drums=EMBER_DR, crash=True),
        dict(chords=E_B_CH, mel=E_B, bass=['pump', 'syncop'], arp='arp16', drums=EMBER_DR, fill=True, inst=(0, 3, 0)),
        dict(chords=E_A_CH, mel=E_A, bass='drive', arp='stab16', drums=EMBER_DR, crash=True, inst=(4, 1, 0)),
        dict(chords=E_B_CH, mel=E_B, bass=['pump', 'syncop'], arp='wave', drums=EMBER_DR, fill=True, inst=(0, 3, 0)),
    ]))
    return songs


def sq_freq_table():
    out = []
    for m in range(128):
        f = note_f(m)
        v = 2048 - round(131072.0 / f) if f >= 64 else 0
        out.append(max(0, min(2047, v)))
    return out


def wv_freq_table():
    out = []
    for m in range(128):
        f = note_f(m)
        v = 2048 - round(65536.0 / f) if f >= 33 else 0
        out.append(max(0, min(2047, v)))
    return out


def wave_ram():
    """two 32-sample (4-bit) waveforms packed into 16 bytes each: bank0 triangle-ish bass, bank1 soft sine."""
    def pack(samples):
        b = []
        for i in range(0, 32, 2):
            b.append((samples[i] << 4) | samples[i + 1])
        return b
    tri_w = []
    for i in range(32):
        v = i / 31.0
        t = 1 - abs(2 * v - 1) * 2 if False else (abs(((i + 8) % 32) - 16) / 16.0)
        tri_w.append(int(round(t * 15)))
    sin_w = [int(round((math.sin(2 * math.pi * i / 32) * 0.5 + 0.5) * 15)) for i in range(32)]
    # add mild harmonic to the sine for a flute-ish tone
    flu = [int(round(max(0, min(15, (math.sin(2 * math.pi * i / 32) * 0.42 + math.sin(4 * math.pi * i / 32) * 0.12 + 0.5) * 15)))) for i in range(32)]
    return pack(tri_w), pack(flu)


def emit_audio(c_path, h_path):
    from common import u8arr, u16arr
    songs = build_songs()
    hdr = ['#ifndef AUDIO_DATA_H', '#define AUDIO_DATA_H', '#include "hw.h"', '']
    hdr.append('typedef struct { const s8 *data; u16 len; u8 prio; } SfxDef;')
    hdr.append('typedef struct { u8 spd; const u8 *tr[4]; } SongDef;')
    for i, (nm, _) in enumerate(SFX):
        hdr.append('#define SFX_%s %d' % (nm, i))
    hdr.append('#define SFX_COUNT %d' % len(SFX))
    for i, s in enumerate(songs):
        hdr.append('#define SONG_%s %d' % (s.name.upper(), i))
    hdr.append('#define SONG_GAMEOVER_NONE 255')
    hdr += ['#define SONG_COUNT %d' % len(songs), '',
            'extern const SfxDef sfx_table[SFX_COUNT];', 'extern const SongDef song_table[SONG_COUNT];',
            'extern const u16 sq_freq[128];', 'extern const u16 wv_freq[128];', 'extern const u8 wave_ram0[16];', 'extern const u8 wave_ram1[16];', '#endif', '']
    src = ['#include "audio_data.h"', '']
    total = 0
    names = []
    for i, (nm, fn) in enumerate(SFX):
        d = fn()
        total += len(d)
        vals = [int(v) for v in d] + [0] * 48
        names.append((nm, len(d)))
        src.append('static const s8 sfx_%d[%d] __attribute__((aligned(4))) = {' % (i, len(vals)))
        for j in range(0, len(vals), 32):
            src.append('  ' + ','.join(str(v) for v in vals[j:j + 32]) + ',')
        src.append('};')
    prios = {'LEVELUP': 9, 'VICTORY': 9, 'GAMEOVER': 9, 'BOSS_DIE': 9, 'BOSS_ROAR': 8, 'EXPLODE': 6, 'CHEST': 7, 'ITEM': 7, 'HURT': 6, 'HIT': 3, 'CRIT': 4,
             'TEXT': 1, 'TEXT2': 1, 'TEXT3': 1, 'MENU_MOVE': 2, 'MENU_OK': 3, 'MENU_BACK': 3, 'SLASH': 2, 'SLASH2': 2, 'COIN': 3,
             'SWING1': 2, 'SWING2': 2, 'THRUST': 2, 'SMASH': 3, 'STAB': 2, 'FLURRY': 2, 'BOW': 2, 'BOW2': 3, 'ZAP': 2, 'ZAP2': 3,
             'HIT_SLASH': 4, 'HIT_STAB': 4, 'HIT_HEAVY': 5, 'HIT_ARROW': 4, 'HIT_MAGIC': 4, 'HIT_BONE': 3, 'HIT_SLIME': 3, 'HIT_ARMOR': 3, 'FINISH': 5}
    src.append('const SfxDef sfx_table[SFX_COUNT] = {')
    for i, (nm, ln) in enumerate(names):
        src.append('  { sfx_%d, %d, %d },' % (i, ln, prios.get(nm, 4)))
    src.append('};')
    songarr = []
    for si, s in enumerate(songs):
        loop = True
        enc = s.encode(loop)
        for ch in range(4):
            src.append(u8arr('song_%d_%d' % (si, ch), enc[ch], 24).replace('const u8', 'static const u8'))
        songarr.append('  { %d, { song_%d_0, song_%d_1, song_%d_2, song_%d_3 } },' % (s.spd, si, si, si, si))
    src.append('const SongDef song_table[SONG_COUNT] = {')
    src += songarr
    src.append('};')
    src.append(u16arr('sq_freq', sq_freq_table()))
    src.append(u16arr('wv_freq', wv_freq_table()))
    w0, w1 = wave_ram()
    src.append(u8arr('wave_ram0', w0))
    src.append(u8arr('wave_ram1', w1))
    open(c_path, 'w').write('\n'.join(src) + '\n')
    open(h_path, 'w').write('\n'.join(hdr) + '\n')
    return total


if __name__ == '__main__':
    import wave
    tot = emit_audio('/tmp/audio_data.c', '/tmp/audio_data.h')
    print('sfx bytes', tot)
    for s in build_songs():
        print(s.name, [len(x) for x in s.encode()])
